// SPDX-License-Identifier: GPL-3.0-only
// Elixir's install page: what the device check says (0.14). web/make_site.py inlines it after fm1pkg.js and
// fm1ota.js; tests/install_test.mjs runs it against simulated FM-1s.
//
// Most alternative firmwares answer FM-1_9xx (Elixir did until 0.21; from 0.22 FM-1_359XXYYZZ) and many share
// one, so the port's name tells them apart: Elixir names its port "Elixir" (a computer may keep showing an older name for it after an update, which
// is Elixir too); Felucca's is "Felucca …".

// the firmware a port's name says: "elixir", "felucca" or null
export function firmwareOf(portName) {
  const m = /elixir|kettle|felucca|wyrd|grimoire/i.exec(portName || "");
  if (!m) return null;
  const n = m[0].toLowerCase();
  return n === "kettle" ? "elixir" : n;              // (by the port's name: Wyrd and Grimoire share FM-1_900 today)
}

// dev: { id: { text, model, version }, name } as Updater.find returns it
export function describe(dev) {
  const id = dev.id, fw = firmwareOf(dev.name);
  if (id.model.toLowerCase().startsWith("ota-"))
    return "In update mode: an install was cut off. Press Install Elixir (or Install official V15) to finish it.";
  if (id.model !== "FM-1") return `${id.text}: not an FM-1.`;
  if (id.version >= 900 && fw === "elixir")
    return `${id.text}: Elixir is installed. Install Elixir (step 3) to update or reinstall it; your projects are kept.`;
  if (id.version >= 900 && fw === "felucca")
    return `${id.text}: Felucca is installed. Back up Felucca's data on its own page first, then install V15 ` +
      "(step 2) if you haven't done so before, or install Elixir (step 3).";
  if (id.version >= 900 && (fw === "wyrd" || fw === "grimoire")) {
    if (fw === "wyrd")                               // (0.24.1: Elixir finds Wyrd's data and asks)
      return `${id.text}: Wyrd is installed. Back up Wyrd's data first on its own library page, then install ` +
        "Elixir (step 3). Elixir finds Wyrd's saved data when it starts and asks before erasing any of it.";
    return `${id.text}: Grimoire is installed. Back up Grimoire's data first on its own library page: Elixir ` +
      "can't yet tell Grimoire's saved data from its own and can write over it. Then install Elixir (step 3).";
  }
  if (id.version === 15) return `${id.text}: official V15. Ready for Elixir: go to step 3.`;
  if (id.version >= 900) return `${id.text}: an alternative firmware (Elixir, Felucca or another). Elixir: ` +
    "install Elixir (step 3) to update it. Another: install V15 (step 2) first if you haven't before.";
  return `${id.text}: an official version other than V15. Install V15 (step 2) first.`;
}
