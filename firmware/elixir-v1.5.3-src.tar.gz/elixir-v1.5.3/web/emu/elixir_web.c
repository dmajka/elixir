/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments (the design: Felucca's web/emu/felucca_web.c,
 * after X0X's browser build, charlesvestal/fm1-x0x, GPL-3.0)
 * Elixir in the browser: the firmware's sources compiled to WebAssembly and run in an AudioWorklet against a
 * simulated FM-1:
 *   - the device clock: TIMER4 ticks (24 MHz) and fm1_ms advance with the audio the worklet asks for; the audio
 *     ISR (audio.c fm1_alnk0_irq, the real one) renders each I2S half as the DMA would ask for it, and the main loop
 *     (main.c's, web_frame) runs every 15 ms, with ui_input every millisecond in between;
 *   - the panel: buttons and encoders by their printed labels (panel.c), the keys as fm1_in.notes, the LEDs read
 *     back from fm1_led / fm1_led_dim / fm1_led_breath / fm1_led_mid through the key matrix;
 *   - the screen: lcd_fill / lcd_blit into a 240 x 240 RGB565 frame;
 *   - the flash: a 1 MiB NOR image behind storage.c's hooks (settings, projects, the session); the page keeps its
 *     sectors in the browser and hands them back at boot.
 * Not here: USB (audio, MIDI out is collected for the page: web_midi_out), the TRS jack, updates.
 * Also built natively (tests/ui_test.c) for the screen and input tests. */
#include <stdint.h>
#include <string.h>
#include <stddef.h>
#undef memset                            /* the firmware's own (libc.c), apart from the host's */
#undef memcpy
#undef memcmp
#define memset elixir_memset
#define memcpy elixir_memcpy
#define memcmp elixir_memcmp

#define __attribute__(x)
#define FELUCCA_FLASH 1
#define FELUCCA_OTA 0
#define FELUCCA_CDC 0
#define FELUCCA_UAC 0
#define FELUCCA_UART 1
#define FELUCCA_CPU2 0
#ifndef ELIXIR_VERSION
#define ELIXIR_VERSION "WEB"
#endif
#define RING_PUBLISH() ((void)0)
#define WEB_SURF 1
static uint16_t web_surf;                       /* (the phone page: the cards' and beat columns' grey, RGB565; 0 the palette's) */
#define POOL
#define RAMBUF
#define RAMHOT
#define NOINITBUF
static volatile uint32_t fm1_ms;
struct { uint32_t magic, failed, pending; } bootguard;
#define BOOTGUARD_MAGIC 0x42475244u

/* ------------------------------------------------------------ the clock --- */
#define FM1_TICKS_PER_US 24u
static uint32_t web_ticks;
static uint32_t fm1_ticks(void) { return web_ticks; }
static void fm1_delay_ms(uint32_t ms) { (void)ms; }

/* --------------------------------------------------------- the panel --- */
#define FM1_NCOL 11u
static const int8_t FM1_KEYMAP[6][FM1_NCOL] = {      /* as hal/fm1_input.h: key id at (column, row bit) */
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
    { 5, 11,  4, 10,  3,  9,  2,  8, -1, -1, -1},
    {34, 35, 36, 37, 38, 40, 39, 13,  7,  6, 12},
    {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33},
    { 0,  1, 15, 14, 17, 16, 19, 18, 20, 21, 22},
    {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
};
static struct { volatile uint32_t notes, buttons; } fm1_in;
static uint8_t fm1_led[FM1_NCOL], fm1_led_dim[FM1_NCOL], fm1_led_breath[FM1_NCOL], fm1_led_mid[FM1_NCOL];
static uint32_t web_dim_lo;
static void fm1_led_dim_level(uint32_t lo) { web_dim_lo = lo; }
static uint32_t web_anim_run, web_anim_t0;
static void fm1_led_anim_start(uint32_t glow) { (void)glow; web_anim_run = 1; web_anim_t0 = web_ticks; }
static int fm1_led_anim_on(void)
{
    if (web_anim_run && (web_ticks - web_anim_t0 > 700u * 1000u * FM1_TICKS_PER_US || fm1_in.notes || fm1_in.buttons))
        web_anim_run = 0;
    return (int)web_anim_run;
}
static uint32_t web_pressed, web_released;
static int32_t web_enc_steps[7];
static uint32_t fm1_input_edges(uint32_t *released)
{
    uint32_t p = web_pressed;
    if (released)
        *released = web_released;
    web_pressed = web_released = 0;
    return p;
}
static uint32_t fm1_input_note_edges(void) { return 0; }
static int32_t fm1_enc_take(uint32_t e) { int32_t s = web_enc_steps[e % 7u]; web_enc_steps[e % 7u] = 0; return s; }

/* ----------------------------------------------------------- the screen --- */
static uint16_t web_fb[240 * 240];       /* RGB565 as the panel gets it (high byte first) */
static uint32_t web_draws;
static void lcd_fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t c)
{
    uint32_t i, j;
    uint16_t sw = (uint16_t)((c >> 8) | (c << 8));
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            web_fb[(y + j) * 240u + x + i] = sw;
    web_draws++;
}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{
    uint32_t i, j;
    for (j = 0; j < h && y + j < 240u; j++)
        for (i = 0; i < w && x + i < 240u; i++)
            web_fb[(y + j) * 240u + x + i] = p[j * w + i];
    web_draws++;
}
static void lcd_sync(void) {}

/* ----------------------------------------------------------- the sources --- */
#define LK_IRQ_OFF() ((void)0)                       /* (1.4: seq.c lk_in) */
#define LK_IRQ_ON() ((void)0)
#include "elixir_tables.h"
#include "lxr_tables.h"
#include "lxr_params.h"
#include "grids_map.h"
#include "../../firmware/src/libc.c"
#include "../../firmware/src/gfx.c"
#include "../../firmware/src/usb.c"
#include "../../firmware/src/midi_uart.c"
#include "../../firmware/src/dsp.c"
#include "../../firmware/src/voices.c"
#include "../../firmware/src/fxbus.c"
#include "../../firmware/src/reverb.c"
#include "../../firmware/src/sound.c"
#include "../../firmware/src/kit.c"
static uint32_t ui_track(void);
static uint32_t ui_pattern(void);
#include "../../firmware/src/seq.c"
#include "../../firmware/src/perform.c"
#include "../../firmware/src/params.c"
#include "../../firmware/src/midi.c"
#include "../../firmware/src/engine.c"

/* the audio ISR (audio.c) against the simulated ALNK0 */
static uint32_t web_half;
#define FM1_AUDIO_HALF 1u
static uint8_t fm1_audio_pending(void) { return FM1_AUDIO_HALF; }
static void fm1_audio_ack_aux(uint8_t p) { (void)p; }
static uint32_t fm1_audio_free_half(void) { return web_half; }
static void fm1_audio_ack_half(void) {}
static void fm1_audio_init(int32_t *buf, uint32_t words, void (*isr)(void), uint32_t prio)
{ (void)buf; (void)words; (void)isr; (void)prio; }
void isr_alnk0(void) {}
#include "../../firmware/src/audio.c"

/* ------------------------------------------------------------ the flash --- */
static uint8_t nor[0x100000];            /* the SPI NOR (erased: 0xFF) */
static uint32_t web_flash_writes;
static uint8_t flash_ok;
static int st_read(uint32_t off, void *dst, uint32_t n)
{
    if (off >= sizeof nor || n > sizeof nor - off)
        return -1;
    memcpy(dst, nor + off, n);
    return 0;
}
static int st_erase_dev(uint32_t off)
{
    if (off >= sizeof nor || 4096u > sizeof nor - off)
        return -8;
    memset(nor + (off & ~4095u), 0xFF, 4096);
    web_flash_writes++;
    return 0;
}
static int st_prog_dev(uint32_t off, const void *src, uint32_t n)   /* NOR: a write only clears bits */
{
    const uint8_t *s = src;
    uint32_t i;
    if (off >= sizeof nor || n > sizeof nor - off)
        return -8;
    for (i = 0; i < n; i++)
        nor[off + i] &= s[i];
    web_flash_writes++;
    return 0;
}
static void flash_hush(void) { out_hush = 1; }  /* (the page's flash is instant: the output keeps its ramp) */
static void flash_unhush(void) { out_hush = 0; }
static uint32_t irq_save(void) { return 0; }
static void irq_restore(uint32_t f) { (void)f; }
static uint32_t fl_jedec_ram(void) { return 0x856014u; }
#define FL_JEDEC_OK(id) ((id) == 0x856014u || (id) == 0xB36014u)
#define FL_FAR(fn) (fn)
#include "../../firmware/src/storage.c"
#include "../../firmware/src/kitlib.c"
#include "../../firmware/src/project.c"
/* 0.7: the library (library.c): the page hands a message in (web_lib_buf, web_lib_in) and takes the answer */
static uint8_t web_lib_inb[1024], web_lib_outb[1024];
static uint32_t web_lib_outn;
static void lib_send(const uint8_t *wire, uint32_t n)
{
    if (n <= sizeof web_lib_outb) {
        memcpy(web_lib_outb, wire, n);
        web_lib_outn = n;
    }
}
#include "../../firmware/src/library.c"

/* ------------------------------------------------- the main loop's HAL --- */
static uint32_t web_master_adc = 700;   /* MASTER, 0..1023 as the ADC reads it */
enum { FM1_ADC_BATT = 3, FM1_ADC_MASTER = 4 };
static int32_t fm1_adc_read(uint32_t ch) { return ch == FM1_ADC_MASTER ? (int32_t)web_master_adc : 620; }
#include "../../firmware/src/master.c"
#include "../../firmware/src/panel.c"
#include "../../firmware/src/ui.c"
#include "../../firmware/src/remote.c"
#include "../../firmware/src/ui_draw.c"

/* --------------------------------------------------------- the device --- */
static uint32_t web_booted, web_boot_ms, web_last_frame;

static void web_power_on(void)                  /* main.c fm1_main's boot */
{
    tables_unpack();                            /* (22: first, as fm1_main) */
    usb.config = 1;                             /* the page is the USB host: MIDI out reaches it (web_midi_out) */
    persist_boot();
    palette_apply();
    draw_splash();
    panel_init();
    engine_init();
    session_boot();
    master_boot();
    audio_init();
    fm1_led_dim_level(kset.leds == 1u);
    fm1_led_anim_start(kset.leds != 0u);
    web_boot_ms = fm1_ms + 1200u;
    web_booted = 1;
}
static void web_frame(void)                      /* one pass of main.c's loop */
{
    master_poll();
    batt_poll();
    lib_poll();
    ui_input();
    settings_poll();
    autosave_poll();
    ui_leds();
    ui_draw();
}

#define RING 4096u
static float ring[RING * 2];
static uint32_t ring_w, ring_r, web_samples_due;

static void web_ms(void)                         /* a millisecond of the device */
{
    fm1_ms++;
    web_ticks += 1000u * FM1_TICKS_PER_US;
    web_samples_due += FS;
    while (web_samples_due >= 1000u * HALF_FRAMES) {
        uint32_t k;
        const int32_t *o = &abuf[web_half * HALF_WORDS];
        web_samples_due -= 1000u * HALF_FRAMES;
        fm1_alnk0_irq();
        for (k = 0; k < HALF_FRAMES; k++) {
            uint32_t i = (ring_w++ % RING) * 2u;
            ring[i] = (float)o[2u * k] / 8388608.0f;
            ring[i + 1] = (float)o[2u * k + 1u] / 8388608.0f;
        }
        web_half ^= 1u;
    }
    if (!web_booted || (int32_t)(fm1_ms - web_boot_ms) < 0)
        return;
    if (web_boot_ms) {
        web_boot_ms = 0;
        lcd_fill(0, 0, 240, 240, T_BG);
        ui.force = 1;
        web_last_frame = fm1_ms - 15u;
    }
    if (fm1_ms - web_last_frame >= 15u) {
        web_last_frame = fm1_ms;
        web_frame();
    } else {
        ui_input();
    }
}

#define EXPORT __attribute__((used, visibility("default")))
#undef __attribute__

static float out_l[1024], out_r[1024];
EXPORT float *web_out_l(void) { return out_l; }
EXPORT float *web_out_r(void) { return out_r; }
EXPORT void web_render(uint32_t n)               /* n frames (<= 1024): the device runs until they exist */
{
    uint32_t k;
    if (n > 1024u)
        n = 1024u;
    while (ring_w - ring_r < n)
        web_ms();
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_r++ % RING) * 2u;
        out_l[k] = ring[i];
        out_r[k] = ring[i + 1];
    }
}
EXPORT uint8_t *web_nor(void) { return nor; }
EXPORT uint32_t web_nor_size(void) { return sizeof nor; }
EXPORT void web_nor_erase(void) { memset(nor, 0xFF, sizeof nor); }
EXPORT uint32_t web_flash_writes_count(void) { return web_flash_writes; }
EXPORT uint8_t *web_lib_buf(void) { return web_lib_inb; }
EXPORT uint8_t *web_lib_out(void) { return web_lib_outb; }
EXPORT uint32_t web_lib_in(uint32_t n)          /* a message F0 .. F7 in web_lib_buf: the answer's length (0: none) */
{
    web_lib_outn = 0;
    if (n >= 2u && n <= sizeof web_lib_inb && web_lib_inb[0] == 0xF0u && web_lib_inb[n - 1u] == 0xF7u)
        lib_in(web_lib_inb + 1, n - 2u);
    return web_lib_outn;
}
EXPORT void web_boot(void)
{
    if (!web_booted)
        web_power_on();
}

/* input by the printed labels: buttons bit b = B_FX .. B_OCTUP (panel.c), keys bit k = key k (F3 .. G5),
 * encoders by role (EN_SELECT .. EN_K4), MASTER 0..1023 */
EXPORT void web_buttons(uint32_t labels)
{
    uint32_t m = 0, b, old = fm1_in.buttons;
    for (b = 0; b < NB; b++)
        if ((labels >> b) & 1u)
            m |= 1u << panel.btn[b];
    web_pressed |= m & ~old;
    web_released |= old & ~m;
    fm1_in.buttons = m;
}
EXPORT void web_keys(uint32_t mask) { fm1_in.notes = mask & ((1u << 27) - 1u); }
EXPORT void web_enc(uint32_t role, int32_t n)
{
    if (role < NE)
        web_enc_steps[panel.enc[role] % 7u] += n * panel.dir[role];
}
EXPORT void web_master(uint32_t v) { web_master_adc = v > 1023u ? 1023u : v; }
EXPORT uint32_t web_midi(uint32_t status, uint32_t d1, uint32_t d2)   /* a message from Web MIDI */
{
    if (status < 0x80u)
        return 1;
    if (status >= 0xF8u)
        return (uint32_t)midi_enqueue(0xFu | status << 8, 1);
    if (status >= 0xF0u)
        return 1;
    return (uint32_t)midi_enqueue((status >> 4) | status << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24, 1);
}
/* MIDI out (the FM-1 sends it over USB): the packets since the last call, for the page's Web MIDI out */
static uint32_t web_mo[256];
EXPORT uint32_t *web_midi_out(void) { return web_mo; }
EXPORT uint32_t web_midi_out_take(void)
{
    uint32_t n = 0;
    while (mo_r != mo_w && n < 256u)
        web_mo[n++] = midi_out_q[mo_r++ % MQ];
    return n;
}

/* the LEDs: bit b = the button labelled b lit (bit 14: PLAY's green), keys bit k */
static uint32_t led_on(const uint8_t *l, uint32_t id)
{
    uint32_t c, r;
    for (c = 0; c < FM1_NCOL; c++)
        for (r = 1; r < 5u; r++)
            if (FM1_KEYMAP[r][c] == (int8_t)id)
                return (l[c] >> r) & 1u;
    return 0;
}
static uint32_t led_buttons(const uint8_t *l)
{
    uint32_t b, m = 0;
    for (b = 0; b < NB; b++)
        m |= led_on(l, panel.btn[b]) << b;
    return m;
}
static uint32_t led_keys(const uint8_t *l)
{
    uint32_t k, m = 0;
    for (k = 0; k < 27u; k++)
        m |= led_on(l, 14u + k) << k;
    return m;
}
EXPORT uint32_t web_lit_buttons(void)
{
    return led_buttons(fm1_led) | ((fm1_led[LED_PLAY_GREEN >> 3] >> (LED_PLAY_GREEN & 7u)) & 1u) << 14;
}
EXPORT uint32_t web_lit_keys(void) { return led_keys(fm1_led); }
EXPORT uint32_t web_dim_buttons(void) { return led_buttons(fm1_led_dim); }
EXPORT uint32_t web_dim_keys(void) { return led_keys(fm1_led_dim); }
EXPORT uint32_t web_dim_level(void) { return web_dim_lo; }
EXPORT uint32_t web_breath_buttons(void) { return led_buttons(fm1_led_breath); }
EXPORT uint32_t web_breath_keys(void) { return led_keys(fm1_led_breath); }
EXPORT uint32_t web_mid_keys(void) { return led_keys(fm1_led_mid); }
EXPORT uint16_t *web_screen(void) { return web_fb; }
EXPORT uint32_t web_screen_draws(void) { return web_draws; }
EXPORT uint32_t web_now_ms(void) { return fm1_ms; }
EXPORT uint32_t web_playing(void) { return sq.running; }
EXPORT uint32_t web_sample_rate(void) { return FS; }
EXPORT uint32_t web_cpu_q8(void) { return cpu_q8; }

/* ------------------------------------------------ the phone page (mobile.html) --- */
/* the four knobs' parameters as the screen shows them: per knob { on, value, min, max } (on 0: nothing to turn) */
static int32_t web_kv[16];
EXPORT int32_t *web_knob_vals(void)
{
    uint16_t pp[4];
    uint32_t k;
    page_params(pp);
    for (k = 0; k < 4u; k++) {
        uint32_t p = pp[k];
        int on = p != VP_NONE && !vp_dead(p) && !(ui.mode == M_SOUND && par_unheard(ui.track, p));
        web_kv[k * 4u] = on;
        web_kv[k * 4u + 1u] = on ? (int32_t)vp_get(p) : 0;
        web_kv[k * 4u + 2u] = on ? (int32_t)vp_min(p) : 0;
        web_kv[k * 4u + 3u] = on ? (int32_t)vp_max(p) : 0;
    }
    return web_kv;
}
/* a slider's drag: n detents on KNOB k+1 as the panel's knob turns it, without the knob's speed-up (the page
 * scales a drag to the parameter's range itself) */
EXPORT void web_knob_turn(uint32_t k, int32_t n)
{
    uint8_t a = kset.accel;
    if (k >= 4u || !n || ui_asking())
        return;
    kset.accel = 0;
    knob_turn(k, n);
    kset.accel = a;
}
EXPORT uint32_t web_bg(void) { return T_BG; }
EXPORT void web_set_surf(uint32_t c) { web_surf = (uint16_t)c; palette_apply(); ui.force = 1; }    /* the screen's background, RGB565 (the palette's) */

/* a pattern to share: the playing pattern, the kit as it sounds (the edit buffer), its name and the tempo, as bytes
 * the page packs into a text (a link). Only between pages of the same layout (KIT_LEN, the pattern's size) */
#define WEB_SHARE_MAGIC 0x31585045u              /* "EPX1" */
#define WEB_SHARE_HEAD 12u
#define WEB_SHARE_V1 (WEB_SHARE_HEAD + KIT_NAME_LEN + KIT_LEN + sizeof(pattern_t))   /* (before the morph) */
#define WEB_SHARE_V2 (WEB_SHARE_V1 + KIT_LEN)   /* .. then the morph target (byte 9: the morph, 10: 1 with it) */
#define WEB_SHARE_V3 (WEB_SHARE_V2 + 1u + NWV)  /* .. then (0.25) 1 if WANDER was on, and its knobs: it sets out on load */
#define WEB_GL3 3u                               /* (the three global LFOs before 1.0 Phase 11's 4th) */
#define WEB_SHARE_V4 (WEB_SHARE_V3 + WEB_GL3 * NGLKGL)   /* .. then (0.25.1) the global LFOs, as a project's KGL1 */
#define WEB_SHARE_V5 (WEB_SHARE_V4 + WEB_GL3)  /* .. then (1.0) their RATEs */
#define WEB_SHARE_V6 (WEB_SHARE_V5 + 1u)        /* .. then (1.0) 1: WANDER's JOURNEY has 1024 BARS (ENDLESS 7) */
#define WEB_SHARE_V7 (WEB_SHARE_V6 + NGLKGL + 1u)   /* .. then (1.0 Phase 11) LFO 4, its 7 bytes and RATE */
#define WEB_LK_MAX (NTRACK * NUM_STEPS * LK_STEP)
/* .. then (1.4) the pattern's locks: a count (u16), then each its track, its key (u16: step << 10 | code), its value.
 * A link from before 1.4 has the pattern as it was then (each step 7 bytes, its two locks in it: WEB_OLD_STEP more
 * bytes; web_share_old) */
#define WEB_OLD_STEP (NTRACK * NUM_STEPS * 4u)
static uint8_t web_share[WEB_SHARE_V7 + WEB_OLD_STEP + 2u + 4u * WEB_LK_MAX];
static void web_gl_put(uint32_t i, const uint8_t *g, uint32_t rate)
{
    gls[i].dest = (uint8_t)(g[0] < NGD ? g[0] : GD_OFF);
    gls[i].depth = (int8_t)clamp32((int8_t)g[1], -127, 127);
    gls[i].len = (uint8_t)(g[2] < NGLEN || g[2] == GL_FREE ? g[2] : 7u);
    gls[i].rate = (uint8_t)(rate & 127u);
    gls[i].wave = (uint8_t)(g[3] == GW_FOLLOW ? GW_FOLLOW : g[3] % NLFO);
    gls[i].mode = (uint8_t)(g[4] < NGM ? g[4] : GM_FREE);
    gls[i].trig = (uint8_t)(g[5] < (g[3] == GW_FOLLOW ? GF_ALL + 1u : NGT) ? g[5] : GT_PLAY);
    gls[i].phase = (uint8_t)(g[6] & 127u);
}
EXPORT uint8_t *web_share_buf(void) { return web_share; }
EXPORT uint32_t web_share_size(void) { return sizeof web_share; }
EXPORT uint32_t web_share_get(void)
{
    uint8_t *b = web_share, *k = b + WEB_SHARE_HEAD + KIT_NAME_LEN;
    uint32_t i, slot = kit_loaded < NUM_KITS ? kit_loaded : 0u;
    b[0] = (uint8_t)WEB_SHARE_MAGIC; b[1] = (uint8_t)(WEB_SHARE_MAGIC >> 8);
    b[2] = (uint8_t)(WEB_SHARE_MAGIC >> 16); b[3] = (uint8_t)(WEB_SHARE_MAGIC >> 24);
    b[4] = (uint8_t)KIT_LEN; b[5] = (uint8_t)(KIT_LEN >> 8);
    b[6] = (uint8_t)sizeof(pattern_t); b[7] = (uint8_t)(sizeof(pattern_t) >> 8);   /* (the layout: 1.4's smaller) */
    b[8] = par[PAR_BPM];
    b[9] = par[PAR_MORPH];
    b[10] = 1;
    b[11] = 0;
    memcpy(b + WEB_SHARE_V1, morph_par, KIT_LEN);
    memcpy(b + WEB_SHARE_HEAD, kit_names[slot], KIT_NAME_LEN);
    for (i = 0; i < KIT_LEN; i++)
        k[i] = par[kit_par(i)];
    memcpy(k + KIT_LEN, &pat[sq.active], sizeof(pattern_t));
    b[WEB_SHARE_V2] = wd.state != WS_IDLE;
    memcpy(b + WEB_SHARE_V2 + 1u, wd.k, NWV);
    for (i = 0; i < NGLFO; i++) {
        uint8_t *g = i < WEB_GL3 ? b + WEB_SHARE_V3 + i * NGLKGL : b + WEB_SHARE_V6;
        g[0] = gls[i].dest; g[1] = (uint8_t)gls[i].depth; g[2] = gls[i].len; g[3] = gls[i].wave;
        g[4] = gls[i].mode; g[5] = gls[i].trig; g[6] = gls[i].phase;
        if (i < WEB_GL3)
            b[WEB_SHARE_V4 + i] = gls[i].rate;
        else
            g[NGLKGL] = gls[i].rate;
    }
    b[WEB_SHARE_V5] = 1;
    {                                            /* (1.4: the locks) */
        uint32_t t, j, n = 0;
        uint8_t *l = b + WEB_SHARE_V7 + 2u;
        for (t = 0; t < NTRACK; t++)
            for (j = lk_at[lk_run(&pat[sq.active], t)]; j < lk_at[lk_run(&pat[sq.active], t) + 1u]; j++, n++) {
                l[4u * n] = (uint8_t)t;
                l[4u * n + 1u] = (uint8_t)LK_KEY(j);
                l[4u * n + 2u] = (uint8_t)(LK_KEY(j) >> 8);
                l[4u * n + 3u] = LK_VAL(j);
            }
        b[WEB_SHARE_V7] = (uint8_t)n;
        b[WEB_SHARE_V7 + 1u] = (uint8_t)(n >> 8);
        return WEB_SHARE_V7 + 2u + 4u * n;
    }
}
/* 1.4: a link from before 1.4 (its pattern 7-byte steps): the pattern to today's layout in place, its locks (two a
 * step: the code's byte, its two high bits in lhi, the value) as 1.4's after the rest; the new length (0: not one) */
static uint32_t web_share_old(uint32_t n)
{
    uint8_t *b = web_share, *q = b + WEB_SHARE_HEAD + KIT_NAME_LEN + KIT_LEN;
    uint32_t i, t, k, nl = 0, rest, hi = (uint32_t)offsetof(pattern_t, lhi) - NTRACK * NUM_STEPS * 3u + NTRACK * NUM_STEPS * 7u;
    static uint8_t l[4u * 2u * NTRACK * NUM_STEPS];
    if (n < WEB_SHARE_V1 + WEB_OLD_STEP)
        return 0;
    for (t = 0; t < NTRACK; t++)
        for (k = 0; k < NUM_STEPS; k++) {
            const uint8_t *x = q + (t * NUM_STEPS + k) * 7u, h = q[hi + t * NUM_STEPS + k];
            for (i = 0; i < 2u; i++) {
                uint32_t c = x[3u + 2u * i] | (uint32_t)(h >> (4u * i) & 3u) << 8;
                if (c == NO_AUTOMATION || !c)
                    continue;
                l[4u * nl] = (uint8_t)t;
                l[4u * nl + 1u] = (uint8_t)(k << 10 | c);
                l[4u * nl + 2u] = (uint8_t)((k << 10 | c) >> 8);
                l[4u * nl + 3u] = x[4u + 2u * i];
                nl++;
            }
            q[hi + t * NUM_STEPS + k] = (uint8_t)(h & 0x4Cu);   /* (the length's bits) */
        }
    for (i = 0; i < NTRACK * NUM_STEPS; i++)         /* (each step's first 3 bytes, together) */
        memmove(q + 3u * i, q + 7u * i, 3);
    rest = n - (WEB_SHARE_HEAD + KIT_NAME_LEN + KIT_LEN + NTRACK * NUM_STEPS * 7u);
    memmove(q + NTRACK * NUM_STEPS * 3u, q + NTRACK * NUM_STEPS * 7u, rest);
    n -= WEB_OLD_STEP;
    if (n < WEB_SHARE_V7)                            /* (an older link's shorter tail: the locks after the full one) */
        memset(b + n, 0, WEB_SHARE_V7 - n);
    b[6] = (uint8_t)sizeof(pattern_t);
    b[7] = (uint8_t)(sizeof(pattern_t) >> 8);
    b[WEB_SHARE_V7] = (uint8_t)nl;
    b[WEB_SHARE_V7 + 1u] = (uint8_t)(nl >> 8);
    memcpy(b + WEB_SHARE_V7 + 2u, l, 4u * nl);
    return n < WEB_SHARE_V7 ? n | 0x80000000u : WEB_SHARE_V7 + 2u + 4u * nl;   /* (bit 31: the tail's length n, the
                                                      * locks after it all the same) */
}
/* web_share_buf's n bytes into the playing pattern and the slot its kit came from (which loads); 0 done, 1 not a
 * share, 2 another layout (another version) */
EXPORT uint32_t web_share_put(uint32_t n)
{
    const uint8_t *b = web_share, *k = b + WEB_SHARE_HEAD + KIT_NAME_LEN;
    uint8_t kit[KIT_LEN];
    pattern_t *p = &pat[sq.active];
    uint32_t i, slot = kit_loaded < 32u ? kit_loaded : 0u;
    uint32_t lks = 0;                            /* (1.4: the locks' place, 0: none) */
    if (n < WEB_SHARE_HEAD || (b[0] | b[1] << 8 | (uint32_t)b[2] << 16 | (uint32_t)b[3] << 24) != WEB_SHARE_MAGIC)
        return 1;
    if ((b[6] | b[7] << 8) == sizeof(pattern_t) + WEB_OLD_STEP && (b[4] | b[5] << 8) == KIT_LEN) {   /* (before 1.4) */
        uint32_t m = web_share_old(n);
        if (!m)
            return 2;
        n = m & 0x7FFFFFFFu;
        lks = 1;
        if (!(m >> 31))
            n = WEB_SHARE_V7;                    /* (a full one: its locks after it) */
    } else if (n >= WEB_SHARE_V7 + 2u) {
        lks = 1;
        if (n != WEB_SHARE_V7 + 2u + 4u * (b[WEB_SHARE_V7] | (uint32_t)b[WEB_SHARE_V7 + 1u] << 8))
            return 2;
        n = WEB_SHARE_V7;
    }
    if ((n != WEB_SHARE_V7 && n != WEB_SHARE_V6 && n != WEB_SHARE_V5 && n != WEB_SHARE_V4 && n != WEB_SHARE_V3 && n != WEB_SHARE_V2 && n != WEB_SHARE_V1) || (b[4] | b[5] << 8) != KIT_LEN || (b[6] | b[7] << 8) != sizeof(pattern_t))
        return 2;
    memcpy(kit, k, KIT_LEN);
    kit_sanitize(kit);
    kit_put(slot, kit);
    for (i = 0; i < KIT_NAME_LEN; i++) {
        uint8_t c = b[WEB_SHARE_HEAD + i];
        kit_names[slot][i] = (char)(c >= 32u && c < 127u ? c : ' ');
    }
    kit_load_ram(slot);
    if (n >= WEB_SHARE_V2 && b[10] == 1u) {  /* the morph target and the morph */
        memcpy(morph_par, b + WEB_SHARE_V1, KIT_LEN);
        kit_sanitize(morph_par);
        kit_set_morph(b[9]);
        snd_post_all();
    }
    memcpy(p, k + KIT_LEN, sizeof(pattern_t));
    p->kit = (uint8_t)slot;                      /* (its voices FREE: the kit is the whole sound) */
    if (p->scale >= NSCALE)
        p->scale = SC_CHROM;
    if (p->groove > NGROOVE)
        p->groove = 0;
    p->sroot %= 12u;
    for (i = 0; i < NTRACK; i++) {
        if (p->len[i] > NUM_STEPS)
            p->len[i] = 16;
        lk_clear(p, i, 0, NUM_STEPS);            /* (1.4: the link's locks, or none) */
    }
    if (lks) {
        uint32_t nl = b[WEB_SHARE_V7] | (uint32_t)b[WEB_SHARE_V7 + 1u] << 8;
        const uint8_t *l = b + WEB_SHARE_V7 + 2u;
        for (i = 0; i < nl && i < WEB_LK_MAX; i++) {
            uint32_t key = l[4u * i + 1u] | (uint32_t)l[4u * i + 2u] << 8;
            if (l[4u * i] < NTRACK && (key & LK_CODE) && (key & LK_CODE) != NO_AUTOMATION)
                (void)lk_put(p, l[4u * i], key >> 10, key & LK_CODE, l[4u * i + 3u]);
        }
    }
    if (b[8] >= 20u)
        par[PAR_BPM] = b[8];
    pat_cp(&pat_backup, p);                      /* (as loaded: a pattern change doesn't drop it) */
    sq.gsync = (1u << NTRACK) - 1u;
    if (n >= WEB_SHARE_V4)                       /* (0.25.1: the global LFOs; older links leave them as they are) */
        for (i = 0; i < WEB_GL3; i++)            /* (1.0: RATE; before, as it was) */
            web_gl_put(i, b + WEB_SHARE_V3 + i * NGLKGL, n >= WEB_SHARE_V5 ? b[WEB_SHARE_V4 + i] : gls[i].rate);
    if (n >= WEB_SHARE_V7)                       /* (1.0 Phase 11: LFO 4) */
        web_gl_put(3, b + WEB_SHARE_V6, b[WEB_SHARE_V6 + NGLKGL]);
    if (n >= WEB_SHARE_V3 && b[WEB_SHARE_V2] == 1u) {   /* (0.25: WANDER with the sharer's knobs, set out) */
        for (i = 0; i < NWV; i++) {
            uint32_t v = b[WEB_SHARE_V2 + 1u + i];
            if (i == WV_JOURNEY && v == 6u && (n < WEB_SHARE_V6 || b[WEB_SHARE_V5] != 1u))
                v = WJ_ENDLESS;                  /* (before 1.0: ENDLESS was 6) */
            wd.k[i] = (uint8_t)(v > vp_max(VP_WD + i) ? vp_max(VP_WD + i) : v);
        }
        if (!sq.running)
            seq_start(1);
        wd_set_out();
    }
    ui.force = 1;
    return 0;
}
