# Phase: the reverbs (1.4, drafted 2026-11-13)

Asked 2026-11-13, after the delays' speedups (docs/TO_DO_PERF_VOICES.md C: MONO 6 → 4%, PING PONG 7 → 4%, TAPE 6 → 4,
TAPE PP 7 → 5): "inspect all 4 reverbs. Can we do anything better to improve the sound of the non-plate reverbs?
They're all a little lackluster. I don't want them to have a higher CPU though."

**The order (the user, 2026-11-13, after step 0's results): "Maybe we just see if we can make them more CPU efficient,
improve the drip reverb, then do lofi and revisit? Boring isn't necessarily bad, and we don't need 4 second tails on
every mode if it's for drums. Not sure how damp works, but maybe it could serve as a better tonal control."** So:
1. **Step 1, cheaper and bit-identical**: all four, PLATE first.
2. **SPRING → the drippy dub spring** (step 2's SPRING item, "SPRING: the drip"): the one sound change now.
3. **LOFI** (step 3).
4. **Then revisit ROOM and HALL** (the rest of step 2) by ear, maybe not at all: their short tails are fine for drums.
   Two small things to raise then: DAMP as a better tone control (below, "DAMP today"), and the quiet send's tail
   cut short by the rounding (step 0's results: cheap to fix, but it changes the sound).

The original goals, as first asked:
1. **Cheaper, bit-identical** (as the voices and delays were): every model, first PLATE (the heaviest).
2. **ROOM, SPRING and HALL sound better, at no more CPU than each costs today** (the budget: each model's device
   instruction count before step 1, and its CONFIG → LOAD → REVERB reading). This changes their sound on purpose:
   not bit-identical, judged by ear (the user's) and by measures (below).
3. **A fifth model, a dirty reverb** (added 2026-11-13: "a dirty reverb which sounds degraded and maybe lofi. Like a
   Pladask Elektrisk Draume guitar pedal, the Caroline Meteore, or something else that's creative. Maybe by degrading
   the trails with SRR or something else we could have a longer tail or something weird"). Scoped in **"LOFI"**
   below; step 3, after step 1 and the new SPRING (the order above; first asked: "rebuild the other models first and
   we can see how much room we have, then build lofi"). Name and knobs decided: LOFI; SIZE = the clock, DAMP = the dirt, SPACE =
   HAVOC ("those parameters sound perfect").

## Where we are: flash and RAM (build of 81079e7, 2026-11-13)

| Budget | Used | Free | Notes |
|---|---|---|---|
| **Flash** (the app slot) | 562,456 of 581,564 B | **19,108 B** | 547,200 after Phase 22 (2026-11-11); 1.4's features since, and today's speedups +3.5 KB (558,968 before ADDTV: unrolled loops, a function per layout) |
| **SRAM above the 8 KiB reserve** | | **18,428 B** | RAM (.data + .bss) 57,208 of 73,728 (16,520 spare) and the pool 370,828 of 380,928 (10,100 spare): one SRAM, any of it will do |
| **RAMTEXT** (code and buffers that run with the flash off) | code 3,124 + .ram_buf 29,132 of 32,544 B | **288 B** | ROOM's buffers (`rev_comb`, `rev_u`) and HALL's state (`hl`) live here: full |
| Packed tables (Phase 22) | 13 tables, 36,404 B in RAM from 4,213 B | | Tier B (LXR_TRI / SAW / REC) still in flash: ~12 / 10.6 / 8.9 KB more flash for 14.3 KB of SRAM each |

So: flash has room for a reverb rework (~19 KB), SRAM has ~18 KB, RAMTEXT none. A new reverb should **reuse the
reverb's existing buffers**, not add any (below).

## The four models today (firmware/src/reverb.c, 627 lines)

Only one model runs at a time (`rv.rtype`; a change fades the old one out and clears everything). The reverb runs on
the mixer's last send, beside the voices, on either core (`reverb_job`), and sleeps when unfed and silent.

| Model | What it is | Rate | Out | Memory it uses | Device instructions a sample (counted, step 0, build of 81079e7) |
|---|---|---|---|---|---|
| **ROOM** (0) | Felucca's Freeverb-like: 4 damped combs (1116–1356 samples) + 2 allpasses, int16 lines | 44.1 kHz | **mono** | `rev_comb` 4,937 + `rev_u.ap` 997 samples (11.9 KB) | **203** (the loop 77, which holds the comb loop 35 and the allpass loop 21 once: + 35 × 3 + 21) |
| **SPRING** (1) | One spring: a low cut, 10 stretched allpasses (a + z^-4)/(1 + a z^-4) (the chirp), a 30–60 ms loop, a one-pole; out at the far end (wobbling) + a quieter tap at 3/4 | 44.1 kHz | **mono** | ROOM's buffers (no RAM of its own) | **198** (the loop 90, holding the stage loop 12 once: + 12 × 9) |
| **HALL** (2) | An 8-line FDN (Paley conference matrix, 21–34 ms lines, mutually prime), 2 input diffusers, 4 lines drifting (±8 samples), 4 low-passed, a low cut | 22.05 kHz | stereo | ROOM's buffers + `hl` (~1 KB state) | **~196** (a block's passes / 64: the send 23 × 32, the 2 diffusers ~19 × 32 + runs each, the 8 lines' ends ~13.5 × 32 + ~100 each, the matrix 123 × 32, the write back 4 × 32 + ~30 a line, the out 21 × 32) |
| **PLATE** (3) | Clouds' reverb (Dattorro's plate), checked against Clouds' code (`tests/reverb_compare.sh`) | 22.05 kHz | stereo | ROOM's allpass buffer + 2 of its combs + `pl_buf` (5,953 samples, 11.9 KB, pool) | **325** ((the loop 559, 55 stack accesses, holding the heads' loop 10 once: + 10 × 9) / 2) |

(1% of a core ≈ 25 instructions a sample in DSP loops, from 1.4's measurements; P FM showed it doesn't always hold.
Every model also pays reverb_job's LEVEL ramp, **26 a sample + a hardware divide** (`/ (int32_t)BLOCK`), and the
return's clear, 3: ~29 + the divide. So ROOM ~232, SPRING ~227, HALL ~225, PLATE ~354 against the unit's 6 / 6 / 6 /
9%: **~38–39 instructions a 1%** for the reverb, a consistent fit.)

### What likely makes ROOM, SPRING and HALL "lackluster" (to confirm by ear and by measure)
- **ROOM**: 4 combs (Freeverb has 8, per side), so sparse and metallic: each comb rings at its own pitch. **Mono**:
  no width at all (HALL and PLATE are stereo). No early reflections, no pre-delay, no modulation: it doesn't sound
  like a room, more like a short metallic tail. Felucca's lengths (1116–1356) are Freeverb's: ~25–30 ms, a "medium
  room" with no small-room option.
- **SPRING**: one spring, **mono**. 10 allpass stages is a thin chirp (Välimäki / Parker / Abel use ~100 stretched
  stages in a few cascades, plus a separate high-frequency path). No "drip" emphasis (a real tank's loop resonance).
  Full rate, so twice the work of what a 22 kHz loop would cost: the cheapest place to buy more stages.
- **HALL**: only 2 input diffusers (Dattorro uses 4), so a hit enters as a few discrete echoes; short lines (21–34 ms
  at 22 kHz: more a big room than a hall) with only 4,937 samples of memory; no pre-delay (a hall's sense of size);
  the output is the lines' ends only (no multi-tap output: less dense, less decorrelated). Its top stops near 10 kHz
  (half rate, plus the 1-2-1 input filter): may be part of "dull".
- All three: output level and EQ may simply sit below PLATE's (the outputs' gains HL_OUT 4, PL_OUT 6 were matched to
  "a kick's tail, a snare's", by ear, once).

### The key enabler: memory is free when shared
Only one model runs at a time, and a change clears the buffers. Today ROOM, SPRING and HALL use only ROOM's 11.9 KB;
PLATE adds `pl_buf`'s 11.9 KB. **Any model may use all of it: `rev_comb` + `rev_u` + `pl_buf` = 11,887 samples
(23.8 KB) at no RAM cost.** That's 2.4× HALL's memory (longer lines, a pre-delay, more diffusers), room for ROOM's
early reflections and a stereo pair of lines, two springs. (`pl_buf` is in the pool, `rev_comb` in RAMTEXT: both are
plain RAM to the DSP; the RAMTEXT split was for the flash-off window, check the reverb never runs in it.)

## Steps

### 0. Measure and tool up (no firmware change)
- [x] **The unit** (2026-11-13, the user's, CONFIG → LOAD → REVERB, a pattern with the send up): **ROOM 6%, SPRING 6%,
      HALL 6%, PLATE 9%**. The budget for step 2: ROOM, SPRING, HALL ≤ 6% each. (So ~200 instructions a sample ≈ 6%:
      ~33 a 1% here, and PLATE ~325 ≈ 9%: ~36. The reverb's loops are memory-heavy: more cycles an instruction.)
- [x] **Device counts** (2026-11-13: in the table above; dis_loops over build/elixir.dis of 81079e7): each model's usual path (as the delays': compile rare paths out, count, add inner loops'
      extra iterations), recorded in the table above in place of the estimates.
- [x] **A host renderer** (2026-11-13, `tests/bench/reverb_bench.c`; how to run it at its top): (a) a bit-identical hash per model over
      SIZE / DAMP / LEVEL / SPACE / a model change / sleep and wake; (b) **WAVs for listening**: each model's impulse
      response and a dry drum loop (kick, snare, hats from render_test's voices) through it at SIZE 32 / 64 / 100,
      stereo, into build/rev/ (and old vs new side by side in step 2). Optionally a page on the local site to A/B them.
- [x] **Measures** (2026-11-13, `tools/reverb_measures.py`, numpy in .venv; `--spec` writes spectrograms): RT60 per octave band (EDC, Schroeder), echo density
      over time (Abel and Huang's normalized echo density: how soon the tail is "smooth"), stereo correlation of the
      tail (IACC: width), the tail's spectral peakiness (how metallic: peaks over a smoothed spectrum), the level
      against PLATE's. Gives "lackluster" numbers to improve and keeps PLATE as the reference.
- [ ] Listen with the user: which of the measures match what they hear as "lackluster".
      The WAVs: build/rev/beat_<MODEL>_s<SIZE>.wav (the beat + the return at LEVEL 100), dry.wav, the IRs, the
      spectrograms spec_*.png.

#### Step 0's results (2026-11-13, build of 81079e7)
Hashes (`build/reverb_bench`, 40 cases; the bit-identical reference for step 1):
```
ROOM    9284896acf3e3e08     SPRING  b20162074b6311cf     HALL    e9e236fd51a41345     PLATE   da785a48b38fc0b0
```
(Each case sleeps and wakes: asleep before the last hit in 29 / 38 / 32 / 12 of 40 cases.)

The measures (`tools/reverb_measures.py build/rev/`, the loud IR; RT60 in seconds by octave band):
```
model    SIZE    pre    125   250   500    1k    2k    4k    8k   dense   ned  width  peaky  level   q/l
ROOM       32  25.3ms  0.88  0.89  0.84  0.87  0.85  0.67  0.44    nanms  0.48   0.00   3.4dB  +6.1dB  0.85
SPRING     32  18.7ms  0.43  0.58  0.60  0.61  0.60  0.43  0.33     95ms  0.46   0.00   4.7dB  +4.2dB  0.84
HALL       32  21.2ms  0.60  0.63  0.71  0.66  0.68  0.55  0.38     57ms  1.02   0.87   3.6dB  -2.0dB  0.40
PLATE      32   0.0ms  2.83  3.03  2.80  2.62  2.40  2.03  1.59     75ms  0.93   0.83   1.5dB  +0.0dB  0.76

ROOM       64  25.3ms  1.21  1.17  1.19  1.18  1.12  0.86  0.51    nanms  0.47   0.00   3.2dB  +5.9dB  0.80
SPRING     64  22.4ms  0.69  0.92  0.96  0.95  0.96  0.66  0.45    112ms  0.51   0.00   3.4dB  +2.1dB  0.86
HALL       64  21.2ms  1.19  1.20  1.16  1.12  1.10  0.84  0.45     58ms  1.03   0.88   3.2dB  -0.1dB  0.39
PLATE      64   0.0ms  4.14  4.39  4.16  4.00  3.45  2.64  1.95     75ms  0.94   0.86   1.3dB  +0.0dB  0.56

ROOM      100  25.3ms  1.95  1.82  1.92  1.96  1.81  1.22  0.62    nanms  0.46   0.00   3.0dB  +5.6dB  0.76
SPRING    100  26.7ms  1.01  1.60  1.81  1.77  1.73  1.05  0.65    131ms  0.47   0.00   3.1dB  +1.7dB  0.82
HALL      100  21.2ms  1.87  1.89  1.94  1.95  1.80  1.19  0.54     58ms  1.03   0.88   2.9dB  +1.0dB  0.26
PLATE     100   0.0ms  9.10 10.06  9.56  8.75  6.91  4.43  2.89     75ms  0.93   0.89   1.1dB  +0.0dB  0.47
```
What they say (to check against the user's ears):
- **The tails are short, and shorter still when the send is quiet** (the biggest finding). At SIZE 64 ROOM, SPRING
  and HALL ring ~1 s against PLATE's ~4 s; HALL's 1.1 s is half its design (0.5 s × 2^(64/30) = 2.2 s), and with a
  quiet send (q/l: the IR to 0.5 against 4.0) HALL's tail is **a quarter to two fifths** as long. The cause: the
  lines are int16 and the send goes in ~22 dB down (mulq15(x, 2580): "ROOM's level"), so a tail reaches the
  rounding's floor (towards zero: no limit cycles, but a quiet tail is cut off) after only a few tens of dB. PLATE
  loses less (its send in at 0.2 into Q14 lines, products to the nearest while loud). Step 2: send in hotter (the
  lines' headroom, as PLATE's), out lower; keep the round-to-nearest-while-loud trick. Free in CPU.
- **ROOM and SPRING are mono** (width 0) and **never get dense** (the echo density stays ~0.5: discrete echoes,
  flutter); ROOM is the most metallic after SPRING (peaky 3.0–3.4 dB against PLATE's 1.1–1.5) and **6 dB louder than
  PLATE**; SPRING 2–4 dB louder. HALL is dense by 57 ms and wide (0.88), but short.
- **Highs**: everyone's 4–8 kHz dies at ~half the mids' time (the damping; HALL and PLATE at half rate). Fine for
  now; DAMP's range is a step 2 question.
- **SPRING's spectrogram** (spec_SPRING_s64.png) shows each echo as a near-vertical click, bent only near the top:
  the "a tenth of the dispersion" finding in "SPRING: the drip", confirmed.
- **For step 1** (free): reverb_job's LEVEL ramp divides every sample (`* (i + 1) / BLOCK`): a shift with the
  rounding towards zero kept is bit-identical.

### 1. Cheaper, bit-identical (as 1.4's other work)
- [x] **PLATE** (2026-11-13): Clouds' own way, per buffer: the lines in one buffer share one write pointer (3: rev_u.ap's
      4 diffusers, rev_comb's D1B + DEL2, pl_buf's other 4), each line at a fixed offset, one wrap test an access; no
      head a line (the heads' loop, ~100 a half-rate sample, gone). `plt.lo` as two functions (plate_run always_inline,
      `plate_rn` / `plate_tz`): 420 against 497 branchless (masks) and 535 one function; costs ~1.4 KB of flash.
      The loop 559 + heads 100 → **420** (half rate): **~325 → ~210 a sample**.
- [x] **ROOM**: its 4 combs fill rev_comb exactly, its 2 allpasses rev_ap: one write pointer each; comb k writes at
      P_k and reads P_k+1 (comb 3 reads P_0 = w), all reads first, so 4 places and 3 wraps a sample (the allpasses: 1);
      unrolled, states in locals. 77 + 35 × 3 + 21 = 203 → **156**.
- [x] **SPRING**: the 10 stages unrolled through a pointer (`SP_STAGE`). 198 → **161** (rebuilt in step 2 anyway).
- [x] **HALL**: the matrix's `x − y0` once a sample (123 → 115, then 117); its lines moved to pl_buf (unused by HALL)
      with HL_NC spare samples after each, so the matrix writes the block straight into the lines and only what passed
      the end is copied (the write-back pass, ~16 a sample, gone). Tried and dropped: the output pass fused into the
      matrix (136 → 159, spills), the write-back two at a time (no gain). **~194 → ~177**.
- [x] **reverb_job's LEVEL**: the ramp's `/ BLOCK` → `sh_tz(.., 6)`, and a loop for a still LEVEL (mono: 11, stereo:
      19) beside the ramp's (27): **26 + a divide → 11 / 19**.
- [x] Each: hash unchanged (all four, the step-0 hashes), render_test's 72 WAVs byte-equal, tests/ci_tests.sh ok.
      `tests/reverb_compare.sh` not run (needs eurorack + stmlib checkouts; PLATE's output is bit-identical, so its
      result can't have moved).
- [x] **Measured on the unit** (the user, 2026-11-13): **ROOM 3–4%, SPRING 3–4%, HALL 5%, PLATE 5%** (were 6 / 6 / 6 /
      9): better than predicted (~33 a 1%, not 38). The 1.4 card and MANUAL §10 updated. The budget for step 2 stays
      the old one (each ≤ 6%), but the new figures are the bar to keep. Predicted, with reverb_job + the clear (~38 a 1%):
      ROOM 232 → ~170 (6 → ~4.5%), SPRING 227 → ~175 (6 → ~4.6%), HALL 225 → ~199 (6 → ~5.2%), PLATE 354 → ~232
      (9 → ~6%). Then the 1.4 card and MANUAL's LOAD figures.

Flash after step 1: 564,652 B (+2,196: PLATE's two copies ~1.4 KB), **16,912 B free**. RAM, RAMTEXT unchanged.
The buffers now: ROOM rev_comb + rev_ap; SPRING rev_comb + rev_ap (int32); HALL pl_buf + rev_ap; PLATE all three.

### 2. Better ROOM, SPRING, HALL at no more CPU (sound changes; the budget: each model's count before step 1)
**Now: SPRING only** (the order at the top); ROOM, HALL, the levels after LOFI, if at all.

**DAMP today** (for the revisit): in every model it is a one-pole low-pass *inside the loop*, so it doesn't set a
tone so much as how much faster the highs die than the mids: ROOM's combs (coefficient 32767 − 200 × DAMP), SPRING's
return (~9 kHz → ~1.3 kHz), HALL's 4 low-passed lines (none → ~1 kHz), PLATE's two branches (none → ~900 Hz). At DAMP
0 the tail is as bright as it goes, never brighter than the send; there's no way to thin it (the bass). A better tone
control, if wanted: DAMP bipolar around the middle, left the loop's low-pass as now (dark, warm), right a low cut
rising in the loop (thin, airy: a reverb that stays out of the kick's way, often what drums want), the middle neither;
or a tilt on the return (cheaper, but static: the tail's tone doesn't change as it decays). Kits store DAMP: a
bipolar DAMP changes old kits (their 48 would become "a little dark"): **accepted** (the user, 2026-11-13: "I think
it's ok to shift reverb tones a bit"), no remap needed. By ear, at the revisit.
Directions to try, each rendered and measured against the old one and against PLATE, then judged by ear:
- [ ] **HALL**: 4 input diffusers (Dattorro's), a pre-delay set by SIZE (10–60 ms), longer lines (up to ~2.4× in the
      shared memory: a real hall's 40–90 ms), a multi-tap stereo output (several taps per line, Dattorro-style, for
      density and width), a gentle high shelf in the loop instead of (or with) the 4 low-passes. Cost: diffusers +2
      allpasses at half rate (~20 a sample), the taps ~10: pay for it with step 1's savings or fewer drifting lines.
- [ ] **ROOM**: rebuilt as a small room, not a short comb tail: **stereo**, early reflections (a pre-delay line with
      6–10 taps, panned, from SIZE's room size), into a small half-rate FDN (HALL's machinery with short lines, 4–8 ms
      .. 25 ms) or a short Dattorro-like loop. Half rate halves the work, so stereo + early reflections can fit in
      today's ~200. SIZE: the room's size (small booth → large room), DAMP: wall absorption.
- [ ] **SPRING → a drippy dub spring** (the user, 2026-11-13: "I'd like a nice drippy dub spring reverb"): see
      **"SPRING: the drip"** below, the research and a design. Do it first of the three.
- [ ] **Levels**: match each model's loudness to PLATE's at the same LEVEL (an RMS of the IR's first 1 s), so a kit
      switching models doesn't jump.
- [ ] Each: the measures (step 0) better than before (denser sooner, wider, less peaky), its device count ≤ the
      budget, the unit's REVERB reading ≤ before; the user's ears decide. Then MANUAL (§10's reverb paragraph, the
      LOAD figures) and the 1.4 card ("ROOM, SPRING and HALL rebuilt: stereo, denser ...").

### SPRING: the drip (researched 2026-11-13)

**Sources.**
- J. Parker, "Efficient Dispersion Generation Structures for Spring Reverb Emulation", EURASIP J. Adv. Signal
  Process. 2011, 646134 (open access, CC BY: https://doi.org/10.1155/2011/646134; PDF at
  https://acris.aalto.fi/ws/portalfiles/portal/13004391/art_10.1155_2011_646134.pdf). Read in full.
- V. Välimäki, J. Parker, J. Abel, "Parametric Spring Reverberation Effect", JAES 58(7/8), 2010: the model Parker
  makes cheaper (paywalled; its structure as Parker summarises it).
- J. Abel, D. Berners, S. Costello, J. O. Smith, "Spring Reverb Emulation Using Dispersive Allpass Filters in a
  Waveguide Structure", AES 121st Conv., 2006 (and Universal Audio's patent US8391504).
- On "drip" itself there is no paper; players' and builders' reports (Premier Guitar's "Lords of the Springs", the
  Valve Wizard's reverb driver page, surfguitar101 threads) agree only that it grows with **dwell** (how hard the
  tank's input is driven: Accutronics advises driving it nearly to saturation), with the tank, and with tone.

**What a spring's impulse response is** (Parker §2, Figs. 4, 6): a train of near-regularly spaced echoes (not a room's
sparse-then-diffuse), each **bent into a chirp** by dispersion: below a transition frequency fC (~4 kHz in real
tanks, "above 5 kHz rarely seen") high frequencies travel slower, so each echo's lows arrive first and its content
sweeps **up to fC over ~40–50 ms**: the "bwoip" of each echo, the drip. Echoes ~55–60 ms apart in Parker's figures;
each pass round the loop disperses again, so later chirps are longer and smeared. A second, wide-band chirp series
(C_hf, falling in pitch, ~30 dB quieter) adds the splash on top.

**The model** (Välimäki et al. as Parker gives it): C_lf = [the input + g_lf × the loop's return] → a cascade of
M_low = 100 *stretched* first-order allpasses A(z^k) = (a + z^-k) / (1 + a z^-k) → (out) → a delay line → back; an
elliptic low-pass at fC on the output (nothing above fC). C_hf the same with M_high = 200 unstretched stages (k = 1).
Plus random modulation of the loop delays, cross-coupling of the two loops, an EQ, and "pre-echoes". A stage's group
delay is k (1 − a²) / (1 + 2a cos(ωk) + a²): at its peak (ωk = π, so fC = fs / 2k) k (1 + a) / (1 − a) samples.
Cost of the original: ~1,023 multiplies a sample. Parker's cheaper one, ~355: C_lf run at **fs / 4**; "chirp
straightening": a Linkwitz-Riley crossover at fC / 2, only the upper band through the allpasses (stretch 2k,
coefficient −a, **half the stages**), the lower band through a matched delay (the chirp's bottom half straightened,
"a slight hardness" on percussion); C_hf with stretch 2 and half its stages. He also suggests **dropping C_hf
altogether** (30 dB down, perceptually minor) for a cheaper effect at "some cost in realism".

**Why ours doesn't drip.** SPRING today: 10 stages, a = 0.7, k = 4 at 44.1 kHz: fC = fs / 8 = 5.5 kHz and a peak
group delay of 4 × 1.7 / 0.3 = 22.7 samples a stage, **227 samples = 5 ms for the chain**. A real tank's chirp
spans ~40–50 ms. **Ours is about a tenth of the dispersion**: each echo is a short click with a tick of chirp, not a
drip. That, not the decay or the tone, is the main thing to fix. (Also: no dwell drive, one spring, mono, and its
loop runs at full rate: the cost spent where it buys least.)

**A design within SPRING's 6% (~200 instructions a sample).**
- **C_lf only, at fs / 4 (11.025 kHz)**, as Parker. At fs / 4 an unstretched stage (k = 1) peaks at Nyquist,
  5.5 kHz: with a = 0.85 that's 1.85 / 0.15 = 12.3 samples = 1.12 ms a stage, so **~45 stages give ~50 ms** of chirp
  (a = 0.8: 9 samples, ~60 stages). A stage costs about 8–12 instructions at the quarter rate, **~2–3 a sample at
  44.1**: 45 stages ≈ 90–135. One int32 state a stage (k = 1): 180 B. The loop's line: 60 ms = 662 samples. Memory
  is nothing next to the 23.8 KB the reverb owns.
- fC: the chain peaks at 5.5 kHz; a low-pass at ~4–4.5 kHz on the return (the spring's band, as Välimäki's H_low)
  leaves the audible chirp topping out near 4 kHz. (A true fC of 4 kHz needs k ≈ 1.4, a fractional stretch:
  Parker's interpolating allpass; try only if the 5.5 kHz peak sounds wrong.)
- Rates: in, a decent low-pass before taking every 4th sample (aliases above 5.5 kHz would fold into the chirp's band;
  the 1-2-1 HALL uses isn't enough at /4: two biquads at 22 kHz, ~10 a sample); out, linear interpolation ×4 then
  the ~4 kHz low-pass (needed anyway). Chirp straightening (the crossover) only if the stage count doesn't fit.
- **Dwell**: a soft saturation on the tank's input (tape_sat's cubic is at hand), driven hard by default: the
  players' drip knob. A knob for it? SIZE (decay and loop length 40–80 ms) and DAMP (the tone: the return's low-pass
  and the loop's damping) are the two the kit has; dwell could follow LEVEL or be fixed high (decide by ear).
- Keep: the low cut (~110 Hz) in the loop, the loop's slow random wobble (Välimäki's delay modulation: a little
  pitch drift in the tail), SPACE (the loop near 0.98).
- **Two springs** (stereo, denser, as an Accutronics tank with 2–3 springs of different lengths): only if the first
  one leaves room. A cheaper width: one spring, two pickups at different points along its loop, panned.
- **Later, a dub gesture** (not in this phase's budget): "kick the tank", a burst of noise into the spring from a
  PERF key, the crash dub engineers got by hitting the reverb unit. Small: a decaying noise burst into the send.

**Chosen and committed (ba3b7d1):** the user liked B (a = 0.75, "lowchirp") but wanted a gentler default and the
option: **SIZE sets the drip** (a = 0.86 − 0.22 (SIZE/127)²: 0.80 at 64, ~0.72 at 100, 0.64 at 127; glides 4 Q12 a
block), dwell fixed at A's. MANUAL §10 (a SPRING paragraph), the 1.4 card, the page's line "Drippy, twangy". To do:
the unit's LOAD → REVERB reading for SPRING (the manual says "about 6% (estimated)": replace it), the user's ears.
**Built (2026-11-13, for listening).** Budget agreed: 5–6% ("I think 5-6% is ok"). As designed above,
with: the decimator a 1 2 3 4 3 2 1 triangle; dwell = softclip_in at drive 3 (Q12 12288) into a Q13 tank; 48 stages
(60 cost ~199 a sample) at a = 0.85, run 4 stages a pass over the 16-sample block (9 instructions a stage-sample;
one at a time was 14); an int32 line (rev_cu.l, 2048); pickups at L/2 and 3L/8 → mid and side (width ~1.0); out by
4-step linear interpolation + a one-pole (~5 kHz) at 44.1 kHz, rounded towards zero (a floor held −1 for ever).
Device: input 101 × 16, chain 12 × (23 + 38 × 16), output 82 × 16 a block → **~165 a sample** (+ 19 + 3 level stage
→ ~5.5–6% predicted). Level ~−5 dB against PLATE (the old SPRING −10..−14, beat RMS). Spectrogram: each echo bends
up into 2–5.5 kHz, later echoes more and lower (the drip). A/B WAVs: build/spring_ab/ (0_old, A_default,
B_lowchirp a = 0.75, C_harddwell drive 6; s32/64/100). Flash +~0.5 KB.

**Checks.** The IR's spectrogram (the host renderer, step 0) should look like Parker's Fig. 6(a)/9: echoes every
~50–60 ms, each a chirp rising to ~4 kHz over ~40–50 ms, lengthening pass by pass. Device count ≤ SPRING's today;
the unit's REVERB line ≤ 6%. Then the user's ears, on a snare and a rimshot with the send up (dub's use).

### 3. LOFI: a degraded, lo-fi reverb (a fifth model; scoped 2026-11-13)

**The references.**
- **Pladask Elektrisk Draume** ("an exploration of artificial reverberation": "post-reverb processing with decay and
  system clock control to break the spatial illusion"). Its manual (https://www.pladaskelektrisk.com/wp-content/uploads/2020/10/DRAUME_manual_ENG_2.pdf,
  v1: .../2020/01/DRAUME_manual_ENG.pdf): **CLK** is the DSP's system clock, so its sample rate: it "affects the
  reverb character", and turning it **pitch-shifts whatever is already reverberating**; very low clocks add noise.
  Decay reaches ~10 minutes at CLK noon. Then, after the reverb: **AM** (random amplitude modulation, a tremolo),
  **FM** (random pitch modulation, a vibrato; in its Eurorack sibling ROM, "random system clock modulation"), **TXT**
  (saturation, "texture"). (A fixed-size delay memory read at a lower clock lasts longer: lower CLK, longer and darker
  and grainier tail. Our SRR idea is exactly this.)
- **Caroline Météore** (lo-fi reverb, ~2015): LEVEL, **ATTACK** (the preamp's gain into the reverb: grit), **SIZE**,
  **REGEN** (decay, up to self-oscillation), a dark / bright switch on some units, and **HAVOC**, a held footswitch
  that runs the tail away into self-oscillation: "seemingly infinite holds, gradual runaways or instant collapse,
  depending on the SIZE". A small, dark, overdriven tank more than a space.
- Not a reference to copy, a family to sound like: neither pedal's circuit or code is known to us; this is our own
  model of what they do (as the delays' TAPE is ours).

**The idea: run the reverb on a slow, wobbly, coarse clock, and let each pass round the loop degrade.**
1. **A variable clock (SRR), from SIZE.** The tank runs at fs / R, R from ~2 (22 kHz) to ~16 (2.8 kHz), *fractional*
   (a phase accumulator, so SIZE sweeps smoothly). In: sample-and-hold every R-th sample with no proper anti-alias
   filter (a one-pole only at most: the aliasing is the character, as the Draume's low CLK). Out: held (zero-order,
   the stair-steps' bright aliases) or linear (darker), a choice by ear, maybe DAMP's. Because the lines stay the same
   length in samples, **a lower clock is a longer, darker tail for free**, and **moving SIZE while it rings
   pitch-shifts the tail** (the Draume's best trick, also free).
   - Memory: all of the reverb's 11,887 int16 samples (rev_comb + rev_u + pl_buf, "the key enabler" above). At R = 2
     that's 0.54 s of line in total; at R = 16, **4.3 s**: lines long enough for slow, smeary echoes as well as a
     wash. (int16 is plenty here: the point is dirt.)
   - CPU: the tank does 1/R of the work. At R ≥ 4 a HALL-sized FDN costs ~a quarter of HALL's: **far under the 6%
     budget**, which pays for the dirt below. (The cheapest model of the five, likely.)
2. **Degradation in the loop, so the tail decays *into* noise and grit, not just quieter:**
   - **Bit reduction** in the feedback path: quantize what's written back to B bits (12 → 6), with or without a
     little dither. Each pass adds its own error, so later echoes are grainier than early ones (the "degraded
     trails"). At low levels a coarse quantizer gates the tail off in steps (lo-fi's crunchy decay): keep, or add a
     tiny noise floor so it hisses out instead (decide by ear).
   - **Saturation** in the loop (TAPE's cubic or a tanh table): the Météore's driven tank, and what keeps HAVOC from
     blowing up.
   - **Darkening per pass** (the one-pole HALL uses, at the low rate: cheap) and a low cut (~100 Hz), so a long tail
     doesn't fill with mud.
   - Optional, by ear: an occasional **dropout** (a random line read skipped / zeroed for a few ms: worn tape, the
     "broken" Draume sound), or a random small **jump of the read heads** (a stutter in the tail).
3. **Wobble, random not sine** (the Draume's AM / FM): FM is free, **jitter the clock** (the phase increment) by a
   slow smoothed random (rnd() into a one-pole): the whole tail's pitch drifts like a warped tape. AM: a slow random
   gain on the output (a few dB). Depth from a fixed default (or DAMP, below).
4. **SPACE = HAVOC**: held, the loop's gain goes just above 1 (into the saturator), so the tail swells into
   self-oscillation and holds; released, it collapses back to SIZE's decay. A small SIZE with HAVOC: a pitched drone
   at the lines' lengths; a large one: a slow runaway roar. (SPACE already means "hold the tail" in the other four:
   this is the dirty model's version.)
5. **Input drive (ATTACK)**: a soft clip on the send before the tank: fixed and fairly hard by default (drums hit it
   hard anyway); or LEVEL drives it and the return's level is compensated (decide by ear).

**The structure.** HALL's FDN (it is general, block-wise, already ours) at the low clock: 4 lines (mono-ish, cheaper,
more "tank") or 8 (stereo, a wash), lengths scaled to fill the 11,887 samples, 1–2 input diffusers at the low rate (a
smear, not a clean build-up: a lo-fi reverb shouldn't be too dense), the quantizer + saturator + one-pole on each line's
write-back (or once, on the input to the matrix: cheaper, check it sounds the same). Stereo out from two sets of
lines' ends. Its per-sample work at full rate: the decimator's phase + hold (~10), the output interpolation (~10), the
wobble (~5); the tank's work at 1/R.

**The knobs (four, as every model):**
| Knob | LOFI |
|---|---|
| SIZE | the clock: from ~22 kHz (a dirty small room) to ~3 kHz (long, dark, grainy, aliased); moving it bends the tail's pitch |
| DAMP | the dirt: bits (12 → 6), the loop's darkening, the wobble's depth, together; or bits only (decide by ear) |
| LEVEL | as every model (maybe drive, above) |
| SPACE (held) | HAVOC: runaway self-oscillation into the saturator |
(The decay is not a knob of its own in this kit (no knob for it in the other models either: SIZE sets it). Here SIZE's
clock already lengthens the tail; the loop's gain could also rise with SIZE, or stay fixed near 0.9 so the clock alone
sets the length. By ear.)

**Costs.** Flash ~1.5–2.5 KB (a new model, the decimator, the dirt; most of the FDN shared with HALL's code if it can
be called with other lengths). RAM: none new (the shared buffers; a few dozen bytes of state, in `hl`'s or a union
with it). The TYPE knob: 0–4, "LOFI" (the user, 2026-11-13: "DIRT" is taken, the master drive is called dirt), params.c's L_REVMODEL, the controllers'
registry (tools/remote_params.py from remote.c), the manual §10, the 1.4 card. Kits store the type: a fifth value
changes no old kit.

**Steps.**
- [ ] After step 1 and the new SPRING (the order at the top: the flash, SRAM and CPU left then set LOFI's room): a prototype on the host
      first, in the step-0 renderer: the IR and the drum loop at SIZE 0 / 32 / 64 / 100, with DAMP low and high, and
      a SIZE sweep while it rings (the pitch bend); a HAVOC hold and release.
      **Built 2026-11-13 (uncommitted), in firmware/src/reverb.c as type 4 (`rev_lofi`, `lf_tick`), tunables as
      `#ifndef LF_*`:** 4 lines (557 / 709 / 877 / 1069 ticks; lines 0, 2 in rev_comb, 1, 3 in pl_buf), Hadamard,
      2 diffusers (113, 337, g 0.625, in rev_ap); R = 2 · 2^(3 SIZE / 127) (2 .. 16), gliding 48 Q16 a block; RT60 =
      22050 ticks (1 s at R 2, 8 s at R 16); the send's one-pole k = min(inc, 0.5) (it tracks the clock: a fixed
      one-pole let an impulse fall between ticks); dwell softclip_in drive 2; each line's write: one-pole
      (32767 − 150 · DAMP), low cut (>> 6), softclip (towards zero), bits cut 0 .. 6 (DAMP); wobble ±0.6 .. 3% (DAMP),
      a smoothed xorshift; HAVOC gain 35000 (Q15); out (m · 4) >> 3, held. Fixed on the way: floors in the loop held
      a limit cycle (the soft clip's >> 3, the one-poles' towards-zero steps: now remainders kept, as HALL): tails end
      in exact silence. Wet level ~0 .. +4 dB against PLATE s64 (beat). `build/reverb_bench lofi DIR TAG` renders
      the set; old four models' hashes unchanged (`-DNOTHER=4`: the bench's model switch draws among 4).
      Flash 566,368 B (+~1.2 KB, 15,196 free); RAM none. Device: lf_tick ~500 a tick unoptimized (the line loop 96 × 4):
      **~300 a sample at SIZE 0** (over budget), ~120 at 64: optimize in the firmware step (unrolled, pointers, no
      lf_line branches), or raise R's floor to 3.
      Listening set: build/lofi/ A_ (default), B_lin_ (LF_LIN 1), C_hot_ (drive 4, HAVOC 40000); beat_/ir_ at
      s0/32/64/100/127 × d10/110, sweep, havoc.
      **The unit (the user, 2026-11-13): SIZE 127 ~4%, 65 ~5%, 0 ~8%; "it just sounds ok".** They suggested SIZE
      65 as the new low: done (`LF_S0` 65, so ≤ ~5% everywhere). SPACE (HAVOC) is PERFORM 2's SPC key, not a knob
      (they looked for it on the page). They asked for overdriven / fuzzy tails instead: two variants, DAMP the fuzz
      (bits fixed at 2, darkening at DAMP 64's): `LF_FUZZ 1` (D_fuzzout_: the return through a soft clip ×1 .. ×16,
      gain 1/2 .. ~1/5: the tail compressed, sustains loud and gritty, then breaks up) and `LF_FUZZ 2` (E_fuzzloop_:
      a drive ×1 .. ×8 in each line's write and back down: loud passes squashed each trip, quiet ones untouched).
      Levels within ~±4 dB of PLATE. The unit's build has the bits (A). Other ideas offered: an octave-up fuzz
      (rectifier in the loop), a gated tail, a reverse swell, "kick the tank".
- [ ] Listen with the user; tune: R's range, the bits, held vs linear out, the wobble, the drive, HAVOC's gain.
- [ ] Firmware: the fifth type, the knob, a hash in the bench, the device count (≤ ROOM's 6%; likely far less), the
      unit's REVERB reading; MANUAL, the site, the 1.4 card.

**Checks.** The spectrogram of the IR at low SIZE should show aliases folding down (mirror images of the input's
spectrum below fs / 2R), the tail's noise floor rising pass by pass at high DAMP, and the pitch moving with a SIZE
sweep. HAVOC must stay bounded (the saturator) and come back down cleanly on release (no stuck DC: the low cut).
Model changes still clear the buffers (so a switch from LOFI to PLATE leaves no grit behind).

### Decisions for the user
- **Replace in place, or keep the old ones?** Kits store the type (0–3) with SIZE / DAMP / LEVEL; a replaced ROOM makes
  every kit on ROOM sound different (the factory kits from the LXR-02 that use the reverb, the user's own). Keeping
  the old ones as more types costs flash (each ~1–2 KB) and a longer TYPE knob. Recommendation: replace, keep the
  knobs' meaning (SIZE = bigger / longer, DAMP = darker) and the level matched, so old kits still sit right.
- **How far from Felucca?** ROOM, SPRING and HALL came from Felucca (credited in reverb.c and the manual): rebuilt,
  they'd be Elixir's own, with the credit kept for the parts that stay.
- **SPRING mono or stereo?** A real tank is often mono (one or two springs to one pickup); stereo is nicer in a mix.

## Tools and notes (from 1.4's speedups, see memory notes on pi32v2 instruction counts)
- `tools/dis_loops.py fn ...`: the loops' sizes; its "min" is the shortest path (often a rare one), and inner loops
  count once: for a usual-path cost, build a throwaway variant with the rare paths compiled out and add the inner
  loops' extra iterations (docs/TO_DO_PERF_VOICES.md C, the TAPE notes).
- Benches: chances from `rnd()`'s top bits (its low bits repeat per case); check each feature is reached (a counter in a
  scratch copy) before trusting a hash.
- Rebuild firmware, emulator and local site after each step; commit per step; don't publish.

**Closed 2026-11-13 for 1.4**: steps 0, 1 and SPRING done. LOFI built but switched off (REV_LOFI 0); it, the dirty tails, shimmer and the ROOM / HALL revisit continue in docs/TO_DO_REVERBS_2.md.
