#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
# Elixir: extract the LXR firmware's ROM tables into firmware/src/lxr_tables.h.
#
#   tools/gen_lxr_tables.py LXR_SRC [OUT]
#
# LXR_SRC is a checkout of the Erica Synths LXR-02 firmware (lxr-desktop-app, GPL-3.0-only). The tables are data of
# that firmware: the band-limited wavetables, the sine, the transient one-shots and the two distortion curves of the
# FX bus. They are copied as they are (integers stay integers; the float curves become Q15). The output is committed,
# so a build never needs the LXR tree; run this again only if the LXR tables change.
import re
import sys
from pathlib import Path


def body(src, name):
    """the numbers of the C array `name` in src, comments stripped"""
    i = src.index(name)
    j = src.index("{", i)
    depth, k = 0, j
    while True:
        c = src[k]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    txt = re.sub(r"/\*.*?\*/", " ", src[j:k + 1], flags=re.S)
    txt = re.sub(r"//[^\n]*", " ", txt)
    return re.findall(r"-?0x[0-9a-fA-F]+|-?\d+\.\d*(?:e-?\d+)?|-?\d+", txt)


def rows(src, name):
    """the rows ({..} groups) of the 2-D C array `name`"""
    i = src.index(name)
    j = src.index("{", i)
    txt = src[j + 1:]
    txt = re.sub(r"/\*.*?\*/", " ", txt, flags=re.S)
    txt = re.sub(r"//[^\n]*", " ", txt)
    out, depth, cur = [], 0, ""
    for c in txt:
        if c == "{":
            depth += 1
            cur = ""
        elif c == "}":
            if depth == 0:
                break
            depth -= 1
            out.append(re.findall(r"-?0x[0-9a-fA-F]+|-?\d+", cur))
        elif depth:
            cur += c
    return out


def ints(tokens):
    return [int(t, 0) for t in tokens]


def s8(v):
    return v - 256 if v > 127 else v


def arr(ctype, name, dims, vals, per=16):
    """a C array; a 2-D one ([R][C] in dims) gets a brace per row"""
    out = [f"static const {ctype} {name}{dims} = {{"]
    m = re.fullmatch(r"\[(\d+)\]\[(\d+)\]", dims)
    rows = [vals[r * int(m.group(2)):(r + 1) * int(m.group(2))] for r in range(int(m.group(1)))] if m else [vals]
    for row in rows:
        if m:
            out.append("    {")
        for i in range(0, len(row), per):
            out.append(("        " if m else "    ") + ", ".join(str(v) for v in row[i:i + per]) + ",")
        if m:
            out.append("    },")
    out.append("};")
    return out


TRANS_PLAY = 2204          # dsp.c's TR_END: the player reads samples 0..2203 of a one-shot
TRANS_TAIL = 1             # (1.4) a one-shot's tail of samples no louder than this is left off: it reads as 0


def trans_tables(trans):
    """(1.4) the one-shots back to back, each without its tail of +-1 and 0 (it reads as 0): ~2.6 KB of flash.
    Almost all of it is one-shot 1's 46 ms of +-1 after its 4 ms click (42 dB under it; no difference heard)"""
    data, ofs = [], [0]
    for r in range(12):
        row = trans[r * 2205:r * 2205 + TRANS_PLAY]
        k = len(row)
        while k and abs(row[k - 1]) <= TRANS_TAIL:
            k -= 1
        data += row[:k]
        ofs.append(len(data))
    L = ["", "/* the transient generator's one-shots: 12 of signed 8-bit samples, up to 2204 played (~50 ms), back to back in",
         " * LXR_TRANS_D without their tails of +-1 and 0 (1.4: lxr_trans_at reads 0 past a one-shot's end) */",
         "#define LXR_TRANS_N 12", f"#define LXR_TRANS_LEN {TRANS_PLAY}"]
    L += arr("uint16_t", "LXR_TRANS_OFS", f"[{len(ofs)}]", ofs)
    L += arr("int8_t", "LXR_TRANS_D", f"[{len(data)}]", data, 24)
    L += ["static inline int32_t lxr_trans_at(uint32_t w, uint32_t i)   /* one-shot w's sample i */",
          "{", "    return i < (uint32_t)(LXR_TRANS_OFS[w + 1u] - LXR_TRANS_OFS[w]) ? LXR_TRANS_D[LXR_TRANS_OFS[w] + i] : 0;",
          "}"]
    return L


def main():
    lxr = Path(sys.argv[1])
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parents[1] / "firmware/src/lxr_tables.h"
    dsp = lxr / "Core/Src/Soundengine/DSPAudio"
    wt = (dsp / "wavetable.c").read_text()
    tr = (dsp / "transientTables.c").read_text()
    fx = (dsp / "FX/Distortion.c").read_text()

    sine = ints(body(wt, "sine_table[TABLESIZE+1]"))
    assert len(sine) == 4097, len(sine)
    tabs = {}
    for n in ("sawTable", "recTable", "triTable"):
        v = ints(body(wt, n + "[11][1024]"))
        assert len(v) == 11 * 1024, (n, len(v))
        tabs[n] = v
    trans = []
    for row in rows(tr, "transientData[NUM_TRANSIENTS][TRANSIENT_SAMPLE_LENGTH]"):
        v = [s8(x) for x in ints(row)]
        assert len(v) <= 2205, len(v)
        trans += v + [0] * (2205 - len(v))          # (C pads a short row with zeros)
    assert len(trans) == 12 * 2205, len(trans)
    ecc = [float(t) for t in body(fx, "ecc83Table[129]")]
    dio = [float(t) for t in body(fx, "table_1n914[257]")]
    assert len(ecc) == 129 and len(dio) == 257

    L = ["/* SPDX-License-Identifier: GPL-3.0-only",
         " * Copyright (C) 2012-2026 Erica Synths (the tables: LXR firmware, Core/Src/Soundengine/DSPAudio)",
         " * Generated by tools/gen_lxr_tables.py from the LXR-02 firmware sources; do not edit. */",
         "#pragma once", "#include <stdint.h>", ""]
    # (1.0: no LXR_SINE; dsp.c's sine_at reads rings_tables.h's RG_SINE a 3/4 cycle on, the same -cos)
    L += ["/* band-limited saw / square / triangle, the LXR's overtone tables 4..10 of 1024 (freqToTableIndex picks one; it never",
          " * picks 0..3, so they are left out: LXR_TAB0) */", "#define LXR_TAB0 4"]
    L += arr("int16_t", "LXR_SAW", "[7][1024]", tabs["sawTable"][4 * 1024:])     # (34: 24 KB of flash)
    L += arr("int16_t", "LXR_REC", "[7][1024]", tabs["recTable"][4 * 1024:])
    L += arr("int16_t", "LXR_TRI", "[7][1024]", tabs["triTable"][4 * 1024:])
    L += trans_tables(trans)
    L += ["", "/* FX bus drive: the ECC83 tube curve (129 points over -1..1) and the 1N914 diode (257 points), Q15 */"]
    L += arr("int16_t", "LXR_ECC83", "[129]", [max(-32768, min(32767, round(v * 32768))) for v in ecc])
    L += arr("int16_t", "LXR_1N914", "[257]", [max(-32768, min(32767, round(v * 32768))) for v in dio])
    out.write_text("\n".join(L) + "\n")
    print(f"lxr tables: {out} ({out.stat().st_size} B)")


if __name__ == "__main__":
    main()
