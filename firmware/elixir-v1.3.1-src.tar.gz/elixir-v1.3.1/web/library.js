// SPDX-License-Identifier: GPL-3.0-only
// Elixir's library (0.7): the protocol of firmware/src/library.c, LXR-02 kit files and backup files, for the library
// page (Web MIDI to an FM-1) and the emulator (its WebAssembly). No DOM here.
//
// A transport is { request(wire: Uint8Array) -> Promise<Uint8Array | null> }: one SysEx message out, the answer
// (F0 .. F7) back, or null after its timeout.

export const STATUS = ["ok", "bad message", "bad arguments", "busy", "flash error", "checksum mismatch", "too big",
  "empty slot", "out of order"];
export const SLOT_NAMES = ["Project 1", "Project 2", "Project 3", "Project 4", "Session (AUTO)"];
const LXR_PARAMS = 247;                              // an LXR-02 kit: 8 name bytes, then these

function pack7(bytes) {
  const out = [];
  let acc = 0, nb = 0;
  for (const b of bytes) {
    acc |= b << nb;
    nb += 8;
    while (nb >= 7) { out.push(acc & 0x7f); acc >>>= 7; nb -= 7; }
  }
  if (nb) out.push(acc & 0x7f);
  return out;
}
function unpack7(seven) {
  const out = [];
  let acc = 0, nb = 0;
  for (const s of seven) {
    acc |= (s & 0x7f) << nb;
    nb += 7;
    if (nb >= 8) { out.push(acc & 0xff); acc >>>= 8; nb -= 8; }
  }
  return Uint8Array.from(out);
}
const u32 = (v) => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
const rd32 = (a, i) => (a[i] | (a[i + 1] << 8) | (a[i + 2] << 16) | (a[i + 3] << 24)) >>> 0;
const nameBytes = (s) => { const b = new Array(8).fill(32); [...(s || "")].slice(0, 8).forEach((c, i) => { const k = c.charCodeAt(0); b[i] = k >= 32 && k < 127 ? k : 32; }); return b; };
export const nameOf = (bytes) => String.fromCharCode(...[...bytes].map((c) => (c >= 32 && c < 127 ? c : 32))).trimEnd();

export function message(cmd, tag, payload = []) {
  const body = [cmd, tag, ...payload];
  const sum = body.reduce((a, b) => a + b, 0);
  body.push(~sum & 255);
  return Uint8Array.from([0xf0, 0x7d, 0x4b, 0x54, ...pack7(body), 0xf7]);
}
export function isLibrary(wire) {
  return wire.length > 5 && wire[0] === 0xf0 && wire[1] === 0x7d && wire[2] === 0x4b && wire[3] === 0x54;
}
function parse(wire) {                               // -> { cmd, tag, status, data } or null
  if (!isLibrary(wire) || wire[wire.length - 1] !== 0xf7) return null;
  const d = unpack7(wire.subarray(4, wire.length - 1));
  if (d.length < 4) return null;
  let sum = 0;
  for (let i = 0; i < d.length - 1; i++) sum += d[i];
  if ((~sum & 255) !== d[d.length - 1]) return null;
  return { cmd: d[0] & 0x7f, tag: d[1], status: d[2], data: d.subarray(3, d.length - 1) };
}

export class Library {
  constructor(transport) { this.t = transport; this.tag = 0; }

  async call(cmd, payload = [], tries = 1) {
    for (let k = 0; k < tries; k++) {
      const tag = (this.tag = (this.tag + 1) & 0x7f);
      const ans = await this.t.request(message(cmd, tag, payload));
      const r = ans && parse(ans);
      if (!r || r.cmd !== cmd || r.tag !== tag) continue;
      if (r.status) {
        const e = new Error(STATUS[r.status] || "error " + r.status);
        e.status = r.status;
        throw e;
      }
      return r.data;
    }
    throw new Error("no answer from Elixir");
  }

  async info() {
    const d = await this.call(0x01, [], 3);
    const info = { proto: d[0], version: nameOf(d.subarray(1, 9)).replace(/\0/g, ""), nlog: d[9], nkits: d[10],
                   kitLen: d[11] | (d[12] << 8), loaded: d[13], kitLoaded: d[14], slots: [] };
    for (let l = 0, i = 15; l < info.nlog; l++, i += 18)
      info.slots.push({ exists: !!d[i], format: d[i + 1], len: rd32(d, i + 2), seq: rd32(d, i + 6),
                        name: nameOf(d.subarray(i + 10, i + 18)) });
    return info;
  }

  async kitNames(n = 64) {
    const names = [];
    for (let first = 0; first < n; first += 32) {
      const d = await this.call(0x02, [first, 32], 3);
      for (let k = 0; k < d[1]; k++) names.push(nameOf(d.subarray(2 + k * 8, 10 + k * 8)));
    }
    return names;
  }

  // a project's image (its 256-byte header block and payload), as it is in flash
  async readProject(slot, onProgress) {
    const head = await this.call(0x10, [slot, ...u32(0), 0, 1], 3);
    const len = 256 + rd32(head, 7 + 16);          // (the header: magic, version, logical, seq, len ..)
    const img = new Uint8Array(len);
    for (let off = 0; off < len; off += 256) {
      const n = Math.min(256, len - off);
      const d = await this.call(0x10, [slot, ...u32(off), n & 255, n >> 8], 3);
      img.set(d.subarray(7, 7 + n), off);
      if (onProgress) onProgress(off + n, len);
    }
    if (!checkImage(img).ok) throw new Error("the project read back damaged; try again");
    return img;
  }

  async writeProject(slot, img, name = "", onProgress) {
    const c = checkImage(img);
    if (!c.ok) throw new Error(c.why);
    await this.call(0x20, [slot, ...u32(img.length), ...(name ? nameBytes(name) : new Array(8).fill(0))]);
    try {
      for (let off = 0; off < img.length; off += 256) {
        const n = Math.min(256, img.length - off);
        await this.call(0x21, [...u32(off), n & 255, n >> 8, ...img.subarray(off, off + n)]);
        if (onProgress) onProgress(off + n, img.length);
      }
      await this.call(0x22);
    } catch (e) {
      try { await this.call(0x23); } catch (_) { /* (it gives up by itself after 10 s) */ }
      throw e;
    }
  }

  loadProject(slot) { return this.call(0x24, [slot]); }
  saveProject(slot, name) { return this.call(0x25, [slot, ...nameBytes(name)]); }

  // data: the kit layout (an LXR .SND's 247 bytes, or a whole Elixir kit)
  kitPut(idx, name, data, loadNow = false) {
    return this.call(0x30, [idx, loadNow ? 1 : 0, ...nameBytes(name), data.length & 255, data.length >> 8, ...data]);
  }
  async kitGet(idx) {
    const d = await this.call(0x31, [idx], 3);
    const n = d[9] | (d[10] << 8);
    return { name: nameOf(d.subarray(1, 9)), data: d.slice(11, 11 + n) };
  }

  // 0.8: an LXR-02 pattern (parsePat) into pattern idx (0..31)
  async patPut(idx, p) {
    await this.call(0x32, [idx]);
    for (let t = 0; t < 7; t++)
      for (let first = 0; first < 64; first += 32) {
        const steps = p.steps[t].subarray(first * 7, (first + 32) * 7), timing = p.timing[t].subarray(first, first + 32);
        await this.call(0x33, [idx, t, first, 32, ...steps, ...timing]);
      }
    const mains = [];
    for (let t = 0; t < 7; t++) for (let b = 0; b < 4; b++) mains.push(p.main[t][b] & 255, p.main[t][b] >> 8);
    await this.call(0x34, [idx, ...mains, p.shuffle, ...p.len, p.kit]);
  }
  songPut(idx, entries) { return this.call(0x35, [idx, ...entries]); }

  // 0.8: the kit library (kind KL_KIT: kits in the kit layout; KL_SOUND: single sounds). -> [{ slot, name }]
  async libList(kind) {
    const out = [];
    for (let first = 0; first < 128; first += 32) {
      const d = await this.call(0x40, [kind, first, 32], 3);
      for (let k = 0; k < d[2]; k++)
        if (d[3 + k * 9]) out.push({ slot: first + k, name: nameOf(d.subarray(4 + k * 9, 12 + k * 9)) });
    }
    return out;
  }
  async libGet(kind, slot) {
    const d = await this.call(0x41, [kind, slot], 3);
    const n = d[10] | (d[11] << 8);
    return { kind, slot, name: nameOf(d.subarray(2, 10)), data: d.slice(12, 12 + n) };
  }
  libPut(kind, slot, name, data) {
    return this.call(0x42, [kind, slot, ...nameBytes(name), data.length & 255, data.length >> 8, ...data]);
  }
  libDelete(kind, slot) { return this.libPut(kind, slot, "", []); }
  // every entry, for a backup file (packKitLib)
  async libBackup(onProgress) {
    const all = [];
    for (const kind of [KL_KIT, KL_SOUND]) all.push(...(await this.libList(kind)).map((e) => ({ kind, ...e })));
    const out = [];
    for (const e of all) {
      out.push(await this.libGet(e.kind, e.slot));
      if (onProgress) onProgress(out.length, all.length);
    }
    return out;
  }
  // 0.24: the CC map (library.c 0x50 / 0x51): 128 codes (ccTargets: 0 the LXR's, CCMAP_OFF nothing)
  async ccMapGet() {
    const d = await this.call(0x50, [], 3);
    return Array.from({ length: 128 }, (_, i) => d[2 * i] | (d[2 * i + 1] << 8));
  }
  ccMapPut(first, codes) {
    return this.call(0x51, [first, codes.length, ...codes.flatMap((c) => [c & 255, c >> 8])]);
  }
  async libRestore(entries, onProgress) {
    let i = 0;
    for (const e of entries) {
      await this.libPut(e.kind, e.slot, e.name, e.data);
      if (onProgress) onProgress(++i, entries.length);
    }
  }
}
export const KL_KIT = 1, KL_SOUND = 2;

// 0.24: the CC map's targets: a code is the parameter + 1, so CC n's is n and NRPN n's is n + 129. The names are the
// manual's (MANUAL.md, "The sound by CC" on). Six numbers per voice-based setting, D1 D2 D3 SN CY HH.
export const CCMAP_OFF = 0xffff;
const VOICES = ["D1", "D2", "D3", "SN", "CY", "HH"];
const LXR_CC = [                                     // [name, the CC per voice (null: none)]
  ["Volume", [89, 90, 91, 92, 93, 94]], ["Pan", [95, 96, 97, 100, 101, 102]], ["Drive", [103, 104, 105, 106, 107, 108]],
  ["Sample rate", [109, 110, 111, 112, 113, 114]], ["Coarse", [9, 11, 13, 15, 17, 19]], ["Fine", [10, 12, 14, 16, 18, 20]],
  ["Waveform", [2, 3, 4, 5, 7, 8]], ["FM waveform", [21, 22, 23, null, null, null]],
  ["Mod 1 waveform", [null, null, null, null, 24, 26]], ["Mod 2 waveform", [null, null, null, null, 25, 27]],
  ["Filter frequency", [38, 39, 40, 41, 42, 43]], ["Filter resonance", [44, 45, 46, 47, 48, 49]],
  ["Attack", [50, 52, 54, 56, 58, 60]], ["Decay", [51, 53, 55, 57, 59, null]], ["Amp slope", [63, 64, 65, 66, 67, 68]],
  ["Repeat", [null, null, null, 69, 70, null]], ["Pitch EG decay", [71, 72, 73, 74, null, null]],
  ["Pitch EG amount", [75, 76, 77, 78, null, null]], ["Pitch EG slope", [79, 80, 81, 82, null, null]],
  ["FM amount", [83, 85, 87, null, null, null]], ["FM frequency", [84, 86, 88, null, null, null]],
  ["LFO frequency", [116, 117, 118, 119, 120, 121]], ["LFO amount", [122, 123, 124, 125, 126, 127]],
];
const LXR_CC1 = [[61, "HH Decay (CH)"], [62, "HH Decay (OH)"], [28, "SN Noise frequency"], [29, "SN Noise / osc mix"],
  [30, "CY Mod 1 frequency"], [31, "CY Mod 2 frequency"], [32, "CY Mod 1 gain"], [33, "CY Mod 2 gain"],
  [34, "HH Mod 1 frequency"], [35, "HH Mod 2 frequency"], [36, "HH Mod 1 gain"], [37, "HH Mod 2 gain"],
  [115, "Global sample rate"]];
const NRPN6 = [                                      // [first NRPN, name, voices (6, or 3: D1-D3)]
  [0, "Filter overdrive"], [6, "FM mode", 3], [15, "Velocity amount"], [27, "LFO waveform"], [51, "LFO clock sync"],
  [57, "LFO offset"], [63, "Filter type"], [69, "Transient volume"], [75, "Transient waveform"],
  [81, "Transient frequency"], [100, "Pulse width"], [174, "FX send"], [180, "Reverb send"], [190, "Bits"],
  [196, "Waveshaper"], [202, "Tilt"], [208, "Choke group"], [214, "Random pitch"], [220, "Random decay"],
  [226, "Random filter"], [232, "Random pan"], [238, "Cross-mod source"], [244, "Cross-mod mode"],
  [250, "Cross-mod amount"], [256, "Model", 3], [262, "Model decay", 3], [268, "Model bright", 3],
  [274, "Model structure", 3], [280, "Model position", 3], [286, "Model exciter", 3], [292, "Model tension", 3],
  [298, "LFO mode"], [304, "Gate"], [325, "LFO 2 rate"], [331, "LFO 2 amount"], [337, "LFO 2 target"],
  [343, "LFO 2 wave"], [349, "LFO 2 mode"], [355, "LFO 2 sync"], [361, "LFO 2 retrigger"], [367, "LFO 2 offset"],
  [373, "Insert type"], [379, "Insert amount"], [385, "Insert knob 3"], [391, "Insert knob 4"],
];
const NRPN1 = [[106, "FX bus type"], [107, "FX bus output"], [108, "FX bus dry/wet"], [109, "Drive curve"],
  [110, "FX bus P1"], [111, "FX bus P2"], [112, "FX bus P3"], [113, "FX bus P4"], [114, "Comp ratio"],
  [115, "Ring carrier waveform"], [117, "Delay mode"], [119, "Roll rate"], [120, "Morph"], [133, "Shuffle"],
  [186, "Reverb size"], [187, "Reverb damping"], [188, "Reverb level"], [189, "Reverb model"], [310, "Delay sync"],
  [311, "Delay saturate"], [312, "Delay echo > reverb"], [313, "Delay glitch"], [314, "Delay pitch"],
  [315, "Bus dirt"], [316, "Master dirt type"], [317, "Master dirt amount"], [318, "Master comp ratio"],
  [319, "Master comp threshold"], [320, "Master comp attack"], [321, "Master comp release"],
  [322, "Master comp sidechain"], [323, "Master comp makeup"], [324, "Master comp mix"]];
export const NO_MAP = new Set([6, 98, 99]);         // (NRPN's own CCs: the firmware never maps them)
const NAMES = new Map();                             // code -> name
for (const [n, ccs] of LXR_CC) ccs.forEach((c, v) => c != null && NAMES.set(c, `${VOICES[v]} ${n}`));
for (const [c, n] of LXR_CC1) NAMES.set(c, n);
for (const [first, n, k = 6] of NRPN6) for (let v = 0; v < k; v++) NAMES.set(first + v + 129, `${VOICES[v]} ${n}`);
for (const [nr, n] of NRPN1) NAMES.set(nr + 129, n);
const NPAR_CODES = 525;                              // (the firmware's NPAR: a code above it is refused)
// a code as a number to type: "CC 9", "NRPN 174"
export const ccCodeRef = (c) => (c <= 128 ? `CC ${c}` : `NRPN ${c - 129}`);
// the label shown and typed: "D1 Coarse (CC 9)"; "" the LXR's, "Off"
export function ccTargetLabel(c) {
  if (!c) return "";
  if (c === CCMAP_OFF) return "Off";
  return NAMES.has(c) ? `${NAMES.get(c)} (${ccCodeRef(c)})` : ccCodeRef(c);
}
// every target, in the page's list order (the LXR's CCs, then by NRPN)
export const CC_TARGETS = [...NAMES.keys()].sort((a, b) => a - b).map((c) => ({ code: c, label: ccTargetLabel(c) }));
// what CC n does with no map
export function ccDefault(cc) {
  if (cc === 0) return "Load a kit";
  if (cc === 1) return "Nothing (the mod wheel)";
  if (NO_MAP.has(cc)) return "NRPN (" + (cc === 6 ? "data entry" : cc === 98 ? "LSB" : "MSB") + ")";
  return NAMES.get(cc) || "Nothing";
}
// a typed target -> its code (0 the LXR's), or null if it isn't one
export function ccParseTarget(text) {
  const t = (text || "").trim();
  if (!t || /^(lxr|default|as the lxr)$/i.test(t)) return 0;
  if (/^(off|none|nothing)$/i.test(t)) return CCMAP_OFF;
  const m = /(?:^|\()\s*(cc|nrpn)\s*(\d+)\s*\)?$/i.exec(t);
  if (m) {
    const n = +m[2], c = /cc/i.test(m[1]) ? n : n + 129;
    if (/cc/i.test(m[1]) ? n >= 2 && n <= 127 && !NO_MAP.has(n) : c <= NPAR_CODES) return c;
    return null;
  }
  const hit = CC_TARGETS.find((x) => x.label.toLowerCase() === t.toLowerCase() || NAMES.get(x.code).toLowerCase() === t.toLowerCase());
  return hit ? hit.code : null;
}
// the map as a CSV: the CCs that differ from the LXR's
export function ccMapCsv(map) {
  const rows = ["cc,sets,name"];
  map.forEach((c, cc) => { if (c) rows.push(`${cc},${c === CCMAP_OFF ? "off" : ccCodeRef(c)},"${c === CCMAP_OFF ? "" : NAMES.get(c) || ""}"`); });
  return rows.join("\n") + "\n";
}
// a CSV back into a whole map (CCs not in it: the LXR's). -> { map, errors: ["line 3: ..."] }
export function ccMapParseCsv(text) {
  const map = new Array(128).fill(0), errors = [];
  text.split(/\r?\n/).forEach((line, i) => {
    const cols = line.split(/[,;\t]/).map((x) => x.trim().replace(/^"|"$/g, ""));
    if (!cols[0] || /^#/.test(cols[0]) || /^cc$/i.test(cols[0])) return;
    const cc = /^\d+$/.test(cols[0]) ? +cols[0] : NaN, c = ccParseTarget(cols[1]);
    if (!(cc >= 0 && cc <= 127)) errors.push(`line ${i + 1}: "${cols[0]}" isn't a CC (0-127)`);
    else if (NO_MAP.has(cc)) errors.push(`line ${i + 1}: CC ${cc} is NRPN's, it can't be mapped`);
    else if (c === null) errors.push(`line ${i + 1}: "${cols[1]}" isn't a parameter (CC n, NRPN n, off)`);
    else map[cc] = c;
  });
  return { map, errors };
}

// 0.19: the Hrtl kit packs (tools/gen_kit_packs.py: .ktlb files in the emulator's kits/). addPacks puts each kit into
// the library's first empty slot (from L1, so they're near the top of the kit browser's LIBRARY): a slot holding a
// kit keeps it, and a kit whose name is in the library already isn't added again.
export const KIT_PACKS = [
  { id: "hrtl-dlc", name: "Hrtl DLC kits", file: "hrtl-dlc.ktlb" },
  { id: "hrtl-untz", name: "Hrtl UNTZ kits", file: "hrtl-untz.ktlb" },
];
export async function fetchPack(base, pack) {          // base: where kits/ is ("../try/", "")
  const r = await fetch(base + "kits/" + pack.file);
  if (!r.ok) throw new Error(`${pack.file}: HTTP ${r.status}`);
  return unpackKitLib(await r.arrayBuffer());
}
export async function addPacks(lib, entries, onProgress = () => {}) {   // -> { added, kept (there already), full }
  const have = await lib.libList(KL_KIT);
  const used = new Set(have.map((e) => e.slot)), names = new Set(have.map((e) => e.name));
  const kits = entries.filter((e) => e.kind === KL_KIT);
  const todo = kits.filter((e) => !names.has(e.name));
  let slot = 0, added = 0;
  for (let i = 0; i < todo.length; i++) {
    while (slot < 128 && used.has(slot)) slot++;
    if (slot >= 128) break;
    await lib.libPut(KL_KIT, slot, todo[i].name, todo[i].data);
    used.add(slot);
    added++;
    onProgress(i + 1, todo.length);
  }
  return { added, kept: kits.length - todo.length, full: todo.length - added };
}

// a kit library backup file: "KTLB", a count, then (kind, slot, name[8], length (2), data) for each entry
export function packKitLib(entries) {
  const out = [0x4b, 0x54, 0x4c, 0x42, ...u32(entries.length)];
  for (const e of entries) out.push(e.kind, e.slot, ...nameBytes(e.name), e.data.length & 255, e.data.length >> 8, ...e.data);
  return Uint8Array.from(out);
}
export function unpackKitLib(buf) {
  const b = new Uint8Array(buf);
  if (!(b[0] === 0x4b && b[1] === 0x54 && b[2] === 0x4c && b[3] === 0x42)) throw new Error("not a Elixir kit library");
  const n = rd32(b, 4), out = [];
  let i = 8;
  for (let k = 0; k < n; k++) {
    if (i + 12 > b.length) throw new Error("the kit library file is cut short");
    const len = b[i + 10] | (b[i + 11] << 8);
    if (i + 12 + len > b.length || b[i] < 1 || b[i] > 2 || b[i + 1] > 127) throw new Error("the kit library file is damaged");
    out.push({ kind: b[i], slot: b[i + 1], name: nameOf(b.subarray(i + 2, i + 10)), data: b.slice(i + 12, i + 12 + len) });
    i += 12 + len;
  }
  return out;
}

// ----------------------------------------------------------------------------------------------- files ---

const MAGIC = 0x4a52504b;                            // "KPRJ" (project.c PROJ_MAGIC)

function crc32(bytes) {                              // zlib's, as storage.c's
  let c = 0xffffffff;
  for (const b of bytes) {
    c ^= b;
    for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
  }
  return ~c >>> 0;
}

// a project image: the header's magic, its own CRC, the payload's length and CRC
export function checkImage(img) {
  if (!(img instanceof Uint8Array) || img.length < 257) return { ok: false, why: "not a Elixir project" };
  const h = img.subarray(0, 48);                    // (proj_hdr_t: 48 bytes, its own CRC last)
  if (rd32(h, 0) !== MAGIC) return { ok: false, why: "not a Elixir project" };
  if (rd32(h, 44) !== crc32(h.subarray(0, 44))) return { ok: false, why: "the project's header is damaged" };
  const len = rd32(h, 16);
  if (img.length !== 256 + len) return { ok: false, why: "the project file is cut short" };
  if (rd32(h, 20) !== crc32(img.subarray(256))) return { ok: false, why: "the project's data is damaged" };
  return { ok: true, format: rd32(h, 4), name: nameOf(h.subarray(24, 32)) };
}

// a backup file: "KTBK", a count, then (slot, length, image) for each project
export function packBackup(entries) {
  const total = 8 + entries.reduce((a, e) => a + 8 + e.img.length, 0);
  const out = new Uint8Array(total);
  out.set([0x4b, 0x54, 0x42, 0x4b, ...u32(entries.length)]);
  let i = 8;
  for (const e of entries) {
    out.set([...u32(e.slot), ...u32(e.img.length)], i);
    out.set(e.img, i + 8);
    i += 8 + e.img.length;
  }
  return out;
}
export function unpackBackup(buf) {                  // -> [{ slot, img }] (also takes a single project image)
  const b = new Uint8Array(buf);
  if (rd32(b, 0) === MAGIC) return [{ slot: -1, img: b }];
  if (!(b[0] === 0x4b && b[1] === 0x54 && b[2] === 0x42 && b[3] === 0x4b)) throw new Error("not a Elixir backup");
  const n = rd32(b, 4), out = [];
  let i = 8;
  for (let k = 0; k < n; k++) {
    const slot = rd32(b, i), len = rd32(b, i + 4);
    if (i + 8 + len > b.length) throw new Error("the backup is cut short");
    out.push({ slot, img: b.slice(i + 8, i + 8 + len) });
    i += 8 + len;
  }
  return out;
}

// an LXR-02 kit file (.SND): its name and parameters. Its number and name come from the file name (NN-NAME.SND).
export function parseSnd(buf, fileName = "") {
  const b = new Uint8Array(buf);
  if (b.length < 8 + 16 || b.length > 8 + LXR_PARAMS + 64) throw new Error("not an LXR kit file");
  const m = /^(\d+)-(.*)\.snd$/i.exec(fileName.split("/").pop() || "");
  let name = nameOf(b.subarray(0, 8)).replace(/\0/g, "").trim();
  if (!name && m) name = m[2].replace(/_+$/, "");
  return { name: name || "Kit", data: b.slice(8, 8 + Math.min(LXR_PARAMS, b.length - 8)), number: m ? +m[1] : null,
           file: fileName };
}
// the kits of an LXR project folder (or loose .SND files), in their numbers' order; "Init"/empty kits left out
export async function sndFiles(files, { skipInit = true } = {}) {
  const kits = [];
  for (const f of files) {
    if (!/\.snd$/i.test(f.name)) continue;
    try {
      const k = parseSnd(await f.arrayBuffer(), f.webkitRelativePath || f.name);
      if (skipInit && (/^(init|initk|initkit|empty|in\s*k)$/i.test(k.name.replace(/\s+/g, " ").trim()) ||
                       /-(INITK|EMPTY|IN__K)\.SND$/i.test(f.name))) continue;
      kits.push(k);
    } catch (_) { /* (not a kit) */ }
  }
  kits.sort((a, b) => (a.file.split("/").slice(0, -1).join("/").localeCompare(b.file.split("/").slice(0, -1).join("/")))
                      || (a.number ?? 999) - (b.number ?? 999) || a.file.localeCompare(b.file));
  return kits;
}
// a kit as an LXR-02 .SND file (its first 247 bytes: Elixir's own settings aren't in the LXR's format)
export function sndBytes(name, data) {
  const out = new Uint8Array(8 + LXR_PARAMS);
  out.set(nameBytes(name).map((c) => c), 0);
  out.set(data.subarray(0, LXR_PARAMS), 8);
  for (let v = 0; v < 6; v++) {                        // (28: Elixir's filter types, past the LXR's OFF: LP there;
    if (out[8 + 191 + v] > 7) out[8 + 191 + v] = 0;     // 25a: its LFO and velocity targets: OFF)
    if (out[8 + 149 + v] >= 229) out[8 + 149 + v] = 0;
    if (out[8 + 167 + v] >= 229) out[8 + 167 + v] = 0;
    const sy = out[8 + 179 + v];                        // (1.0: its LFO sync's 3/4 3/8 5/16 3/16: the LXR's nearest,
    if (sy > 11) out[8 + 179 + v] = [3, 5, 5, 7][sy - 12] ?? 0;   // 1/1 1/3 1/3 1/6)
    if (out[8 + 155 + v] > 7) out[8 + 155 + v] = 5;    // (1.1: its LFO's SMOOTH, DRIFT: RANDOM)
  }
  return out;
}

// an LXR-02 pattern file (.PAT): V3 ("PatV03": the steps' timing, the kit), V2 (no timing), V1 (no tag, no kit).
// -> { name, version, steps[7] (64 x 7 bytes: the LXR's Step), timing[7] (64), main[7][4], shuffle, len[7], kit }
const PAT_STEPS = 64 * 7;
export function parsePat(buf, fileName = "") {
  const b = new Uint8Array(buf);
  const tag = String.fromCharCode(...b.subarray(8, 14));
  const version = /^PatV0[23]$/.test(tag) ? +tag[5] : 1;
  const size = { 1: 8 + 7 * PAT_STEPS + 56 + 1 + 7, 2: 14 + 7 * PAT_STEPS + 56 + 1 + 7 + 1,
                 3: 14 + 7 * (PAT_STEPS + 64) + 56 + 1 + 7 + 1 }[version];
  if (b.length < size) throw new Error("not an LXR pattern file");
  let i = version === 1 ? 8 : 14;
  const steps = [], timing = [], main = [], len = [];
  for (let t = 0; t < 7; t++) {
    steps.push(b.slice(i, i + PAT_STEPS));
    i += PAT_STEPS;
    if (version === 3) { timing.push(b.slice(i, i + 64)); i += 64; } else timing.push(new Uint8Array(64).fill(0x70));
  }
  for (let t = 0; t < 7; t++) {
    main.push([]);
    for (let k = 0; k < 4; k++, i += 2) main[t].push(b[i] | (b[i + 1] << 8));
  }
  const shuffle = b[i++];
  for (let t = 0; t < 7; t++) len.push(b[i++]);
  const kit = version === 1 ? 0 : b[i];
  const m = /^(\d+)-/.exec(fileName.split("/").pop() || "");
  return { name: nameOf(b.subarray(0, 8)).replace(/\0/g, "").trim(), version, steps, timing, main, shuffle, len,
           kit: kit < 64 ? kit : 0, number: m ? +m[1] : null, file: fileName };
}
// an LXR-02 song file (.SNG): its name, 64 entries (pattern 0..63, END 64, LOOP 65)
export function parseSng(buf, fileName = "") {
  const b = new Uint8Array(buf);
  if (b.length < 8 + 64) throw new Error("not an LXR song file");
  const m = /^(\d+)-/.exec(fileName.split("/").pop() || "");
  return { name: nameOf(b.subarray(0, 8)).replace(/\0/g, "").trim(), entries: [...b.subarray(8, 72)],
           number: m ? +m[1] : null, file: fileName };
}
// a song's entries for Elixir's 32 patterns: LXR's patterns from `first` (0 or 32) are 0..31; the rest the last
export function songWindow(entries, first) {
  return entries.map((e) => (e >= 64 ? e : e >= first && e < first + 32 ? e - first : 31));
}
// the folders that hold LXR-02 files (.SND, .PAT, .SNG): a picked folder's own and its subfolders' (a whole SD card: one
// per project, PROJ00 …)
export function lxrFolders(files) {
  const dirs = new Set();
  for (const f of files)
    if (/\.(snd|pat|sng)$/i.test(f.name)) dirs.add((f.webkitRelativePath || f.name).split("/").slice(0, -1).join("/"));
  return [...dirs].sort();
}
// an LXR-02 project folder: its kits (by number), patterns and songs. -> { kits, pats, songs }. One project only: the
// numbers of two would collide
export async function lxrProject(files) {
  const dirs = lxrFolders(files);
  if (dirs.length > 1)
    throw new Error(`That folder holds ${dirs.length} LXR-02 projects (${dirs.slice(0, 3).map((d) => d.split("/").pop()).join(", ")}` +
                    `${dirs.length > 3 ? " …" : ""}). Pick one project's folder.`);
  const kits = await sndFiles(files, { skipInit: false }), pats = [], songs = [];
  for (const f of files) {
    const path = f.webkitRelativePath || f.name;
    try {
      if (/\.pat$/i.test(f.name)) pats.push(parsePat(await f.arrayBuffer(), path));
      else if (/\.sng$/i.test(f.name)) songs.push(parseSng(await f.arrayBuffer(), path));
    } catch (_) { /* (not one) */ }
  }
  const byNum = (a, b) => (a.number ?? 999) - (b.number ?? 999);
  return { kits: kits.filter((k) => k.number !== null && k.number < 64), pats: pats.filter((p) => p.number !== null).sort(byNum),
           songs: songs.filter((s) => s.number !== null && s.number < 64).sort(byNum) };
}
// an LXR project into Elixir: its kits into their slots (so the patterns' kit numbers still name them), its patterns
// from `first` (0: 1..32, 32: 33..64) into the patterns, its songs (those not empty)
export async function importLxrProject(lib, proj, first = 0, onProgress = () => {}) {
  const pats = proj.pats.filter((p) => p.number >= first && p.number < first + 32);
  const songs = proj.songs.filter((s) => s.entries[0] !== 64);
  const total = proj.kits.length + pats.length + songs.length;
  let n = 0;
  for (const k of proj.kits) { await lib.kitPut(k.number, k.name, k.data); onProgress(++n, total); }
  for (const p of pats) { await lib.patPut(p.number - first, p); onProgress(++n, total); }
  for (const s of songs) { await lib.songPut(s.number, songWindow(s.entries, first)); onProgress(++n, total); }
  return { kits: proj.kits.length, pats: pats.length, songs: songs.length };
}

// ----------------------------------------------------------------------------------------- transports ---

// Web MIDI: the FM-1's port (Elixir names itself "Elixir", Kettle "Kettle"), SysEx allowed
export async function midiTransport(access, log = () => {}) {
  const outs = [...access.outputs.values()];
  for (const input of access.inputs.values()) {
    if (input.state === "disconnected" || !/elixir|kettle|fm-1|felucca|usb-midi/i.test(input.name || "")) continue;
    const output = outs.find((o) => o.name === input.name && o.state !== "disconnected");
    if (!output) continue;
    await input.open();
    await output.open();
    let waiter = null, timeout = 1500;               // (short while probing a port; then room for a flash erase)
    input.onmidimessage = (ev) => { if (waiter && isLibrary(ev.data)) { const w = waiter; waiter = null; w(ev.data); } };
    const t = {
      name: input.name,
      request(wire, ms = timeout) {
        return new Promise((resolve) => {
          const tm = setTimeout(() => { waiter = null; resolve(null); }, ms);
          waiter = (d) => { clearTimeout(tm); resolve(new Uint8Array(d)); };
          output.send(wire);
        });
      },
      close() { input.onmidimessage = null; },
    };
    try {
      await new Library(t).call(0x01, [], 2);
      timeout = 6000;
      log("found " + input.name);
      return t;
    } catch (_) {
      t.close();
    }
  }
  return null;
}

// the emulator: its WebAssembly exports (web_lib_buf, web_lib_in, web_lib_out) and memory
export function wasmTransport(exp, memory) {
  return {
    name: "emulator",
    async request(wire) {
      const mem = () => new Uint8Array(memory.buffer);
      mem().set(wire, exp.web_lib_buf());
      const n = exp.web_lib_in(wire.length);
      return n ? mem().slice(exp.web_lib_out(), exp.web_lib_out() + n) : null;
    },
  };
}
